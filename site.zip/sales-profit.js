// Both UI choices optimize the same cash flow: sold surplus minus actual start/seed costs.
export const isSalesProfit = target => target === 'coins' || target === 'direct_sale_profit';
export const solverPriorities = priorities => [...new Set(priorities.map(target => isSalesProfit(target) ? 'coins' : target))];

export function selectPriority(order, index, on) {
    return order.map((p, i) => ({ ...p, on: i === index ? on
        : on && isSalesProfit(order[index].target) && isSalesProfit(p.target) ? false : p.on }));
}

// Imported/saved settings may contain both aliases. Preserve the first enabled rank.
export function reconcileSalesPriorities(order) {
    let selected = false;
    return order.map(p => {
        if (!p.on || !isSalesProfit(p.target)) return p;
        const on = !selected; selected = true;
        return { ...p, on };
    });
}

// Goal quantities use the same continuous approximation as the time-to-goal solver.
// Never value gross production here: total_units already excludes ingredients consumed.
export function salesBreakdown(goal) {
    const rows = (goal.products || []).map(p => {
        const sales = p.total_units * p.sell_value;
        return { ...p, sales, costs: Math.max(0, sales - p.total_value), net: p.total_value };
    });
    const total = rows.reduce((sum, r) => ({ sales: sum.sales + r.sales, costs: sum.costs + r.costs,
        net: sum.net + r.net, rate: sum.rate + r.rate_per_second }), { sales: 0, costs: 0, net: 0, rate: 0 });
    return { rows, total };
}
