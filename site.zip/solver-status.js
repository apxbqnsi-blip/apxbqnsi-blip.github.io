// Keep failure causes separate: a timed-out search does not establish infeasibility.
export function solverFailureMessage(problem, stage) {
    const failure = problem.solve_failure || {};
    if (failure.status === 'Time limit reached') {
        return `${stage}: ${failure.time_limit ?? 180}초 제한 안에 실행 가능한 계획을 확보하지 못했습니다 (탐색 시간 초과)`;
    }
    if (failure.status === 'Infeasible') {
        return `${stage}: 계산기가 현재 조건을 동시에 만족할 수 없다고 판정했습니다 (조건 충돌)`;
    }
    return `${stage}: 계산 결과를 확보하지 못했습니다 (계산기 상태: ${failure.status || '확인되지 않음'})`;
}
