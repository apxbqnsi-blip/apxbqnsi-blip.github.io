// Shared by the read-only browser loader and the deployment builder.
export const MODULES = ['ecological_module', 'kitchen_module', 'resource_detector', 'crafting_module'];
const fail = message => { throw new Error(`Invalid game data: ${message}`); };
const integer = (n, min = 0) => Number.isSafeInteger(n) && n >= min && n <= 4294967295;
const positive = n => typeof n === 'number' && Number.isFinite(n) && n > 0;
const nonnegative = n => typeof n === 'number' && Number.isFinite(n) && n >= 0;
const object = value => value !== null && typeof value === 'object' && !Array.isArray(value);

export function validateCatalog(data) {
    if (data?.schema_version !== 1) fail('unsupported schema version');
    if (!Array.isArray(data.facilities) || !data.facilities.length || !Array.isArray(data.recipes)
        || !data.recipes.length || !Array.isArray(data.rv_levels) || !data.rv_levels.length) {
        fail('facilities, recipes and RV levels are required');
    }
    const buildings = new Set(), slugs = new Set(), names = new Set(), levels = new Set();
    const protectedSizes = {'Farmland':[2,2],'Woodland':[4,4],'Mine':[5,5],'Well':[2,2],
        'Tidewhisper Sandcastle':[5,5],'Dewy House':[2,2],'Nimbus Bed':[5,5],
        'Starfall Hammock':[5,5],'Floral Windmill':[5,5],'Heat Furnace':[1,1],'Cooling Unit':[2,2],'Sunlamp':[1,1]};
    for (const f of data.facilities) {
        if (!object(f) || !/^[A-Za-z0-9][A-Za-z0-9 '-]*$/.test(f.name || '') || buildings.has(f.name)) fail('duplicate or invalid facility name');
        if (!/^[a-z0-9-]+$/.test(f.slug || '') || slugs.has(f.slug)) fail(`invalid facility ID: ${f.name}`);
        if (!['Materials','Environment','Aniimo Materials','Materials Processing'].includes(f.category)
            || !Array.isArray(f.size) || f.size.length !== 2 || !f.size.every(positive)) fail(`invalid facility category/size: ${f.name}`);
        if (protectedSizes[f.name] && f.size.some((n,i) => n !== protectedSizes[f.name][i])) fail(`unsupported environment footprint: ${f.name}`);
        if (f.category === 'Environment' && !['Heat Furnace','Cooling Unit','Sunlamp'].includes(f.name)) fail('new environment facilities require an engine update');
        buildings.add(f.name); slugs.add(f.slug);
    }
    for (const r of data.recipes) {
        if (!object(r) || !/^[a-z0-9_]+$/.test(r.name || '') || names.has(r.name)) fail('duplicate or invalid recipe ID');
        names.add(r.name);
        if (!buildings.has(r.facility)) fail(`unknown facility for ${r.name}`);
        if (!positive(r.production_time) || !integer(r.yield_amount, 1) || !integer(r.facility_level, 1)
            || !nonnegative(r.sell_value)) fail(`invalid recipe values: ${r.name}`);
        if (r.cost != null && !nonnegative(r.cost) || r.workload != null && !positive(r.workload)) fail(`invalid cost/workload: ${r.name}`);
        if (r.min_rv_level != null && !integer(r.min_rv_level, 1)) fail(`invalid RV requirement: ${r.name}`);
        if (r.special_unlock != null && typeof r.special_unlock !== 'boolean') fail(`invalid special unlock: ${r.name}`);
        if (!integer(r.ability_level ?? 1, 1)) fail(`invalid ability level: ${r.name}`);
        if (r.module_requirement != null && (!Array.isArray(r.module_requirement) || r.module_requirement.length !== 2
            || !MODULES.includes(r.module_requirement[0]) || !integer(r.module_requirement[1], 1))) fail(`invalid module requirement: ${r.name}`);
        if (!['coins','none','aniimo_exp','aniipods'].includes(r.sell_currency)) fail(`unknown currency: ${r.name}`);
        const inputs = r.raw_materials ?? [], amounts = r.required_amount ?? [];
        if (!Array.isArray(inputs) || !Array.isArray(amounts) || inputs.length !== amounts.length
            || !amounts.every(n => integer(n, 1))) fail(`invalid ingredients: ${r.name}`);
        if (r.grower_steps != null && (!Array.isArray(r.grower_steps) || r.grower_steps.some(s =>
            !object(s) || !s.step || !s.ability || !integer(s.min_level, 1) || !positive(s.workload)))) fail(`invalid grower tasks: ${r.name}`);
        if (r.environment && !['Cool','Warm','Freeze','Scorching','Adequate'].includes(r.environment)) fail(`unknown environment: ${r.name}`);
        if (r.environment && !['Farmland','Woodland','Mine','Tidewhisper Sandcastle','Dewy House','Nimbus Bed','Starfall Hammock','Floral Windmill'].includes(r.facility)) fail(`unsupported facility environment: ${r.name}`);
        if (r.byproduct != null && (!Array.isArray(r.byproduct) || r.byproduct.length !== 2
            || !['Wood Blocks','Mineral Sand'].includes(r.byproduct[0]) || !integer(r.byproduct[1], 1))) fail(`invalid byproduct: ${r.name}`);
        if (r.season != null && (!object(r.season) || !nonnegative(r.season.points) || !nonnegative(r.season.seed_cost))) fail(`invalid season values: ${r.name}`);
    }
    const byproducts = new Set(data.recipes.flatMap(r => r.byproduct ? [r.byproduct[0] === 'Wood Blocks' ? 'wood_block' : 'mineral_sand'] : []));
    const graph = new Map(data.recipes.map(r => [r.name, r.raw_materials ?? []]));
    const visited = new Set(), visiting = new Set();
    const visit = name => {
        if (visiting.has(name)) fail(`cyclic ingredients: ${name}`);
        if (visited.has(name) || byproducts.has(name)) return;
        if (!names.has(name)) fail(`missing ingredient: ${name}`);
        visiting.add(name); graph.get(name).forEach(visit); visiting.delete(name); visited.add(name);
    };
    names.forEach(visit);
    for (const row of data.rv_levels) {
        if (!object(row) || !integer(row.level, 1) || levels.has(row.level)) fail('duplicate or invalid RV level');
        levels.add(row.level);
        for (const name of buildings) {
            const tier = row.facilities?.[name];
            if (!object(tier) || !integer(tier.count) || !integer(tier.level, 1)) fail(`missing or invalid facility limits at RV ${row.level}: ${name}`);
        }
        for (const module of MODULES) if (!integer(row.modules?.[module])) fail(`invalid module limit at RV ${row.level}: ${module}`);
        if (!integer(row.aniimo_max, 1)) fail(`invalid Aniimo limit at RV ${row.level}`);
        const cost = row.level_up_cost;
        if (cost != null && (!object(cost) || !nonnegative(cost.coins) || !Array.isArray(cost.items)
            || cost.items.some(item => !Array.isArray(item) || item.length !== 2
                || (!names.has(item[0]) && !byproducts.has(item[0])) || !positive(item[1])))) fail(`invalid level-up cost at RV ${row.level}`);
    }
    if (data.translations != null && (!object(data.translations) || Object.values(data.translations).some(v => typeof v !== 'string'))) fail('invalid translations');
    return data;
}
