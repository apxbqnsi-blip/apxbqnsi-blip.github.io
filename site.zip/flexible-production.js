// Convert the optimizer's average recipe workloads into actual, numbered facilities.
// A physical unit keeps its level and environment when its recipe changes.
import { recipeLimit } from './solver-settings.js';
const EPS = 1e-6;
const recipeMap = recipes => new Map(recipes.map(r => [r.name, r]));
const ingredientsOf = r => r?.ingredients || r?.raw_materials || [];
const amountsOf = r => r?.amounts || r?.required_amount || [];
export const FIXED_CROP_FACILITIES = new Set(['Farmland', 'Woodland']);

function mergeRecipeJobs(jobs) {
    const merged = new Map();
    for (const j of jobs) {
        if (!merged.has(j.item)) merged.set(j.item, { ...j, busy: 0, rate: 0, variants: [] });
        const job = merged.get(j.item);
        job.busy += j.busy; job.rate += j.rate; job.variants.push(j);
        job.requiredLevel = Math.max(job.requiredLevel, j.requiredLevel);
    }
    return [...merged.values()].map(j => {
        const crews = [...new Set(j.variants.map(v => v.crew).filter(v => v != null))];
        return { ...j, cycle: j.busy / j.rate, crews, crew: crews.length === 1 ? crews[0] : null,
            mixedCycles: new Set(j.variants.map(v => v.cycle)).size > 1 };
    });
}

export function allocateFlexibleUnits(plan, input, recipes) {
    const limit = recipeLimit(input);
    const index = recipeMap(recipes);
    const residents = new Set(input.roster?.residents || []);
    const groups = new Map();
    const units = [];
    const solvedGroups = Array.isArray(plan.shared_facilities) ? plan.shared_facilities : null;
    const expected = new Map();
    const workKey = (facility, item, cycle, crew, pool) => JSON.stringify([facility, item, cycle, crew ?? null, pool ?? null]);
    for (const row of plan.coin_items || []) {
        if (row.status !== 'producing' || !(row.cycle_time > 0)) continue;
        const busy = row.busy_units ?? row.facility_count;
        if (!(busy > EPS)) continue;
        const recipe = index.get(row.item_name);
        if (!recipe) throw new Error(`레시피 정보를 찾을 수 없습니다: ${row.item_name}`);
        const job = {
            item: row.item_name, cycle: row.cycle_time, busy, rate: busy / row.cycle_time,
            requiredLevel: recipe.facility_level ?? recipe.facilityLevel ?? 1,
            crew: row.crew ?? null,
        };
        const environment = row.environment || null;
        const sensitive = !environment && !!recipe.environment;
        const base = { facility: row.facility, environment, sensitive, worker_pool: row.worker_pool };
        if (residents.has(row.facility) || FIXED_CROP_FACILITIES.has(row.facility)) {
            // Residents and crop plots keep one recipe for the entire plan.
            for (let i = 0; i < row.facility_count; i++) {
                const share = busy / row.facility_count;
                units.push({ ...base, resident: residents.has(row.facility), fixedCrop: FIXED_CROP_FACILITIES.has(row.facility), requiredLevel: job.requiredLevel,
                    jobs: [{ ...job, busy: share, rate: share / job.cycle }] });
            }
        } else if (solvedGroups) {
            const key = workKey(row.facility, row.item_name, row.cycle_time, row.crew, row.worker_pool);
            expected.set(key, (expected.get(key) || 0) + busy);
        } else {
            const key = JSON.stringify([row.facility, environment, row.worker_pool ?? null]);
            if (!groups.has(key)) groups.set(key, { ...base, jobs: [] });
            const group = groups.get(key);
            group.sensitive ||= sensitive;
            group.jobs.push(job);
        }
    }
    if (solvedGroups) {
        const actual = new Map();
        solvedGroups.forEach((g, i) => {
            if (FIXED_CROP_FACILITIES.has(g.facility) || residents.has(g.facility)) throw new Error(`${g.facility}: 작물 고정·상주 전용 시설은 교대할 수 없습니다.`);
            if (new Set(g.jobs.map(j => j.item_name)).size > limit) throw new Error(`${g.facility}: 한 시설에는 최대 ${limit}개 레시피만 배정할 수 있습니다.`);
            const jobs = g.jobs.map(j => {
                const r = index.get(j.item_name);
                if (!r || !(j.busy_units > 0) || !(j.cycle_time > 0)) throw new Error('병행 생산 배정 정보가 올바르지 않습니다. 다시 계산하세요.');
                const key = workKey(g.facility, j.item_name, j.cycle_time, j.crew, g.worker_pool);
                actual.set(key, (actual.get(key) || 0) + j.busy_units);
                return { item: j.item_name, cycle: j.cycle_time, busy: j.busy_units, rate: j.busy_units / j.cycle_time,
                    crew: j.crew ?? null, requiredLevel: r.facility_level ?? r.facilityLevel ?? 1 };
            });
            if (!Number.isInteger(g.count) || g.count < 1 || jobs.reduce((s, j) => s + j.busy, 0) > g.count + EPS) throw new Error(`${g.facility}: 시설 가동량이 배정 수를 초과합니다.`);
            groups.set(`solved:${i}`, { facility: g.facility, worker_pool: g.worker_pool, environment: g.environment || null, requiredLevel: g.min_level,
                sensitive: !g.environment && jobs.some(j => !!index.get(j.item)?.environment), jobs });
        });
        for (const key of new Set([...expected.keys(), ...actual.keys()])) {
            if (Math.abs((expected.get(key) || 0) - (actual.get(key) || 0)) > EPS * Math.max(1, expected.get(key) || 0)) {
                throw new Error('레시피 생산량과 시설별 배정이 다릅니다. 다시 계산하세요.');
            }
        }
    }
    for (const group of groups.values()) {
        // Higher requirements first: at every level threshold the pool uses exactly
        // ceil(total work requiring that level) units, matching the solver's constraints.
        const jobs = group.jobs.sort((a, b) => b.requiredLevel - a.requiredLevel || a.item.localeCompare(b.item));
        let unit = null;
        for (const job of jobs) {
            let remaining = job.busy;
            while (remaining > EPS) {
                if (!unit || unit.busy >= 1 - EPS || (!unit.jobs.some(j => j.item === job.item) && new Set(unit.jobs.map(j => j.item)).size >= limit)) {
                    unit = { facility: group.facility, worker_pool: group.worker_pool, environment: group.environment,
                        sensitive: group.sensitive, requiredLevel: Math.max(group.requiredLevel || 1, job.requiredLevel), busy: 0, jobs: [] };
                    units.push(unit);
                }
                const share = Math.min(remaining, 1 - unit.busy);
                unit.jobs.push({ ...job, busy: share, rate: share / job.cycle });
                unit.busy += share;
                remaining -= share;
            }
        }
    }

    const poolKey = (facility, pool) => JSON.stringify([facility, pool ?? null]);
    const available = new Map(Object.entries(input.facilities || {}).map(([facility, tiers]) => [poolKey(facility),
        tiers.flatMap(t => Array.from({ length: t.count }, () => ({ level: t.level }))).sort((a, b) => a.level - b.level),
    ]));
    for (const pool of plan.worker_pools || []) {
        available.delete(poolKey(pool.facility));
        available.set(poolKey(pool.facility, pool.id), pool.units.map(number => ({ level: pool.level, number })));
    }
    units.sort((a, b) => a.facility.localeCompare(b.facility) || b.requiredLevel - a.requiredLevel);
    for (const unit of units) {
        unit.jobs = mergeRecipeJobs(unit.jobs);
        if (unit.jobs.length > (FIXED_CROP_FACILITIES.has(unit.facility) ? 1 : limit)) throw new Error(`${unit.facility}: 레시피 교대 상한을 초과합니다.`);
        const levels = available.get(poolKey(unit.facility, unit.worker_pool)) || [];
        const position = levels.findIndex(slot => slot.level >= unit.requiredLevel);
        if (position < 0) throw new Error(`${unit.facility}: 필요한 레벨의 시설 수가 부족하여 병행 배치를 만들 수 없습니다.`);
        Object.assign(unit, levels.splice(position, 1)[0]);
    }

    // Spare physical units may eliminate switches. Covered units can only spread to slots
    // actually supplied by the solved environmental geometry, never to invented coverage.
    const coverage = new Map();
    for (const a of plan.environment_assignments || []) for (const layout of a.layouts || []) for (const p of layout) {
        const key = JSON.stringify([p.facility, a.mode]);
        coverage.set(key, (coverage.get(key) || 0) + 1);
    }
    for (const u of units) if (u.environment) {
        const key = JSON.stringify([u.facility, u.environment]);
        coverage.set(key, (coverage.get(key) || 0) - 1);
    }
    for (const unit of [...units]) {
        if (unit.resident) continue;
        const levels = available.get(poolKey(unit.facility, unit.worker_pool)) || [];
        for (let j = unit.jobs.length - 1; j > 0; j--) {
            const key = JSON.stringify([unit.facility, unit.environment]);
            if (unit.environment && (coverage.get(key) || 0) <= 0) break;
            const job = unit.jobs[j];
            const position = levels.findIndex(slot => slot.level >= job.requiredLevel);
            if (position < 0) continue;
            units.push({ ...unit, ...levels.splice(position, 1)[0], requiredLevel: job.requiredLevel,
                jobs: [job], busy: job.busy });
            unit.jobs.splice(j, 1);
            if (unit.environment) coverage.set(key, coverage.get(key) - 1);
        }
    }
    const numbered = new Map();
    for (const unit of units) {
        if (unit.worker_pool == null) {
            unit.number = (numbered.get(unit.facility) || 0) + 1;
            numbered.set(unit.facility, unit.number);
        }
        unit.id = `${unit.facility}#${unit.number}`;
        unit.busy = unit.jobs.reduce((sum, job) => sum + job.busy, 0);
        if (unit.busy > 1 + EPS) throw new Error(`${unit.id}: 시설 가동량이 100%를 초과합니다.`);
    }
    const { order } = productionOrder(units, recipes);
    units.forEach(u => u.jobs.sort((a, b) => order.get(a.item) - order.get(b.item) || a.item.localeCompare(b.item)));
    return units;
}

// Rank ingredients before their consumers across the entire plan, including quick recipes
// and byproducts. Cycles are reported rather than presented as an executable startup order.
export function productionOrder(units, recipes) {
    const index = recipeMap(recipes);
    const names = [...new Set(units.flatMap(u => u.jobs.map(j => j.item)))].sort();
    const makers = new Map();
    for (const name of names) {
        const r = index.get(name);
        const byproduct = r?.byproduct_item || (typeof r?.byproduct === 'string' ? r.byproduct : r?.byproduct?.[0]);
        for (const item of [name.replace(/^quick_/, ''), byproduct].filter(Boolean)) {
            if (!makers.has(item)) makers.set(item, []);
            makers.get(item).push(name);
        }
    }
    const waiting = new Set(names);
    const order = new Map();
    let level = 0;
    while (waiting.size) {
        const ready = [...waiting].filter(name => ingredientsOf(index.get(name)).every(item =>
            !(makers.get(item) || []).some(producer => waiting.has(producer))));
        if (!ready.length) break;
        ready.forEach(name => { order.set(name, level); waiting.delete(name); });
        level++;
    }
    waiting.forEach(name => order.set(name, level));
    return { order, cyclic: [...waiting] };
}

export function rotationGuide(unit, recipes, order, seconds = 86400) {
    const index = recipeMap(recipes);
    const jobs = [...unit.jobs].sort((a, b) => (order.get(a.item) || 0) - (order.get(b.item) || 0) || a.item.localeCompare(b.item));
    return jobs.map(job => {
        const r = index.get(job.item);
        const targetBatches = job.rate * seconds;
        const batches = Math.floor(targetBatches + EPS);
        const requirements = n => ingredientsOf(r).map((item, i) => ({ item, amount: (amountsOf(r)[i] ?? 1) * n }));
        return { ...job, targetBatches, targetSeconds: job.busy * seconds, batches,
            batchSeconds: batches * job.cycle, interval: 1 / job.rate,
            materials: requirements(batches), oneBatchMaterials: requirements(1) };
    });
}

export function flexiblePlanSteps(units) {
    return units.map(u => ({
        item_name: u.jobs[0].item, facility: u.facility, facility_count: 1, status: 'producing',
        environment: u.environment, busy_units: u.busy, cycle_time: u.jobs[0].cycle,
        jobs: u.jobs, unitId: u.id, unitNumber: u.number, level: u.level, sensitive: u.sensitive,
    }));
}

// Display every physical production unit, including environment-dependent Aniimo facilities.
// Two recipes on one unit share one table row and one footprint, never two copies of the unit.
export function flexibleFacilityRows(plan, units) {
    const sources = (plan.coin_items || []).filter(r => r.status === 'producing');
    const grouped = new Map();
    for (const unit of units) {
        const sourceSteps = sources.filter(r => r.facility === unit.facility
            && (r.worker_pool ?? null) === (unit.worker_pool ?? null)
            && (r.environment || null) === (unit.environment || null)
            && unit.jobs.some(j => j.item === r.item_name));
        if (!sourceSteps.length) throw new Error(`${unit.facility}: 생산 표의 레시피 정보를 찾을 수 없습니다.`);
        const key = unit.jobs.length === 1 && unit.worker_pool == null
            ? JSON.stringify([unit.facility, unit.environment, unit.level, sourceSteps.map(r => sources.indexOf(r))])
            : unit.id;
        if (grouped.has(key)) {
            const row = grouped.get(key);
            row.facility_count++;
            row.busy_units += unit.busy;
            row.unit_ids.push(unit.id);
        } else {
            grouped.set(key, { ...sourceSteps[0], facility_count: 1, busy_units: unit.busy,
                environment: unit.environment, jobs: unit.jobs, source_steps: sourceSteps,
                unit_ids: [unit.id], level: unit.level,
                reason: unit.jobs.length > 1 ? `한 시설에서 아래 전환 안내에 따라 ${unit.jobs.length}개 레시피를 교대합니다.` : sourceSteps[0].reason });
        }
    }
    return [...grouped.values()];
}
