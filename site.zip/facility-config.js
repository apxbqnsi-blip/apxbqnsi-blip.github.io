import { activeCatalog, setupAt } from './catalog-store.js';
import { SEASON as LEGACY_SEASON } from './base-facility-config.js';
import { unlockRecipes } from './recipe-unlocks.js';
export { HOMELAND_PLOTS, HOMELAND_PLOT_SIZE, LEVEL_UP_CHAINS, ANIIPOD_TIERS, PERSONALITY_PAIRS, personalityLetter, opposedPersonality, FACILITY_CATEGORIES } from './base-facility-config.js';
export const SEASON = { ...(activeCatalog.season_config || LEGACY_SEASON), recipeNotes: unlockRecipes(activeCatalog.recipes, true) };
export const SPECIAL_RECIPES = unlockRecipes(activeCatalog.recipes);
export const RV_LEVELS = activeCatalog.rv_levels.map(r => r.level).sort((a,b) => a-b);
export const MAX_HOME_LEVEL = Math.max(...RV_LEVELS);
export const FACILITIES = activeCatalog.facilities.map(f => {
    const unlocks = {};
    for (const row of [...activeCatalog.rv_levels].sort((a,b)=>a.level-b.level)) {
        const tier = row.facilities[f.name];
        if (tier.count) unlocks[tier.level] ??= row.level;
    }
    // A later RV can unlock facility levels that did not exist in the original catalog.
    return {...f,unlocks,hasLevels: f.hasLevels !== false || Object.keys(unlocks).some(level => Number(level) > 1)};
});
export const FACILITY_FOOTPRINTS = { 'Storage Unit': [2,2], ...Object.fromEntries(FACILITIES.map(f => [f.name, f.size])) };
export const FACILITY_CATEGORY_BY_NAME = new Map(FACILITIES.map(f => [f.name,f.category]));
export const ANIIMO_MAX = Object.fromEntries(activeCatalog.rv_levels.map(r => [r.level-1,r.aniimo_max]));
export const LEVEL_UP_COSTS = Object.fromEntries(activeCatalog.rv_levels.filter(r => r.level_up_cost).map(r => [r.level,r.level_up_cost]));
export const MODULE_MAX_LEVELS = Object.fromEntries(['ecological_module','kitchen_module','resource_detector','crafting_module'].map(m => [m, Object.fromEntries(activeCatalog.rv_levels.map(r => [r.level-1,r.modules[m]]))]));
export const simpleSetup = level => setupAt(activeCatalog, level);
