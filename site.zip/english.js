import { englishUi } from './locales/english-ui.js';
import { englishErrors } from './locales/english-errors.js';
import { gameEnglish, gameKorean, legacyKorean } from './locales/english-terms.js';

const phrases = { ...legacyKorean, ...gameEnglish, ...englishUi, ...englishErrors };
const SLOT = /\{[a-z_]+\}/gi;
const NUMBER = /^\{(?:n|count|unit|level|amount|minutes|seconds|hours|days|total|reserved|ordinary|plots|other|trips|distance|width|height|gap)\}$/;
const escape = text => text.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const templates = Object.entries(phrases).filter(([source]) => /\{[a-z_]+\}/i.test(source))
    .sort(([a], [b]) => b.replace(SLOT, '').length - a.replace(SLOT, '').length)
    .map(([source, target]) => {
        const slots = [...source.matchAll(SLOT)].map(m => m[0]);
        const parts = source.split(SLOT);
        const pattern = parts.map((part, i) => escape(part) + (i < slots.length
            ? NUMBER.test(slots[i]) ? '([+-]?[0-9][0-9.,]*)' : '(.+?)' : '')).join('');
        const breaks = ['\n', ' · ', ' → '].filter(separator => !source.includes(separator));
        return { slots, target, breaks, pattern: new RegExp(`^${pattern}$`, 's') };
    });

// Match complete names, longest first. Including canonical names makes this
// idempotent ("Fresh Water" must not modify "Plain Fresh Water" a second time).
const termPattern = new RegExp(`(?<![\\p{L}\\p{N}_])(?:${Object.keys(gameEnglish).sort((a, b) => b.length - a.length).map(escape).join('|')})(?![\\p{L}\\p{N}_])`, 'gu');
const canonical = text => text.replace(termPattern, term => gameEnglish[term]);

export const englishKorean = {
    ...gameKorean,
    ...Object.fromEntries(Object.entries({ ...englishUi, ...englishErrors }).map(([ko, en]) => [canonical(en), ko])),
};

function direct(text, depth) {
    if (Object.hasOwn(phrases, text)) return canonical(phrases[text]);
    const recurse = part => part === text ? part : translateEnglish(part, depth + 1);
    for (const { slots, target, pattern, breaks } of templates) {
        const match = text.match(pattern);
        if (!match) continue;
        if (slots.some((slot, i) => !['{reason}', '{sequence}'].includes(slot) && !NUMBER.test(slot) && breaks.some(b => match[i + 1].includes(b)))) continue;
        // Insert by slot name once: a captured user value containing "$&" or a
        // placeholder must never be interpreted as a replacement instruction.
        const captures = Object.fromEntries(slots.map((slot, i) => [slot, recurse(match[i + 1])]));
        return canonical(target.replace(SLOT, slot => captures[slot] ?? slot));
    }
    return null;
}

/** Translate display text only; internal IDs, form values and user data stay untouched. */
export function translateEnglish(value, depth = 0) {
    if (!value || depth > 16) return value;
    const text = value.trim();
    const exact = direct(text, depth);
    if (exact !== null) return value.replace(text, () => exact);
    if (text.endsWith('.')) {
        const sentence = direct(text.slice(0, -1), depth);
        if (sentence !== null) return value.replace(text, () => sentence + '.');
    }
    const recurse = part => part === text ? part : translateEnglish(part, depth + 1);
    for (const separator of ['\n', '. ', ' · ', '; ', ' → ', ' / ', ', ', ': ']) {
        if (!text.includes(separator)) continue;
        const parts = text.split(separator);
        const sources = separator === '. ' ? parts.map((p, i) => p + (i < parts.length - 1 ? '.' : '')) : parts;
        let translated;
        if (separator === '. ') {
            // A layout summary can be followed by a multi-sentence guide. Match
            // the longest known sentence group before splitting individual lines.
            translated = [];
            for (let i = 0; i < sources.length;) {
                let match = null, end = i + 1;
                for (let j = sources.length; j > i; j--) {
                    const found = direct(sources.slice(i, j).join(' '), depth + 1);
                    if (found !== null) { match = found; end = j; break; }
                }
                translated.push(match ?? recurse(sources[i])); i = end;
            }
        } else translated = sources.map(recurse);
        const joined = translated.join(separator === '. ' ? ' ' : separator);
        if (joined !== text) return value.replace(text, () => joined);
    }
    // Time and rate fragments can share a text node with punctuation or an
    // English label; each fragment keeps its numeric value.
    const fragments = text
        .replace(/(?<![\p{L}\p{N}])([0-9]+)일(?:\s|$)/gu, '$1d ')
        .replace(/(?<![\p{L}\p{N}])([0-9]+)시간(?=\s|$|\))/gu, '$1h')
        .replace(/(?<![\p{L}\p{N}])([0-9]+)분(?=\s|$|\))/gu, '$1 min')
        .replace(/(?<![\p{L}\p{N}])([0-9]+)초(?=\s|$|\))/gu, '$1s')
        .replace(/([0-9][0-9.,]*)회\/시간/g, '$1 batches/hour');
    return value.replace(text, () => canonical(fragments.trim()));
}
