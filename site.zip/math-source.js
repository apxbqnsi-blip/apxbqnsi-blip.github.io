// Keep the math window before MathJax typesets it. This script runs while the page is still
        // being parsed, and MathJax typesets only after that. See math-translation.js.
        window.aniimaxMathSource = document.querySelector('#mathModal .modal-body').innerHTML;
