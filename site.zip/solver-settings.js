export const SOLVE_TIME_CHOICES = [60, 120, 180, 300, 600];
export function solveOptionsFor(input = {}, strict = false) {
    const seconds = input.solver_time_limit ?? 180;
    if (!SOLVE_TIME_CHOICES.includes(seconds)) throw new Error('최대 계산 시간은 1·2·3·5·10분 중에서 선택하세요.');
    return { mip_rel_gap: 0, time_limit: seconds, ...(strict ? { mip_feasibility_tolerance: 1e-9 } : {}) };
}
export function recipeLimit(input = {}) {
    const limit = input.max_recipes_per_facility ?? 2;
    if (![2, 3].includes(limit)) throw new Error('시설당 교대 레시피 수는 2개 또는 3개여야 합니다.');
    return limit;
}
