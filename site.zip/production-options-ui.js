import { compareProduction, isEvent, productOf, productionRates, recipeBlockers, validateEvents, EVENT_ABILITIES, defaultEventJobs, eventCycle, withEventRecipes, findEventCrop, eventCropRecipes, eventPreset, eventSeedCurrency } from './production-options.js';
import { recipeLimit } from './solver-settings.js';
import { translateEnglish } from './english.js';

export const productionOptionFields = ['recipe-target-input', ...[1, 2].flatMap(i => ['name', 'recipe', 'count', 'environment', 'description', 'yield', 'sell', 'seed', 'season-seed', 'season-points', 'growth-minutes', 'watering', 'watering-level', 'watering-seconds', 'jobs'].map(f => `event-${i}-${f}`))];
let eventTranslate = value => value;
const escapeHtml = value => String(value ?? '').replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
function storedJobs(i) { try { return JSON.parse(document.getElementById(`event-${i}-jobs`).value); } catch { return null; } }
export function migrateEventDefaults(data) {
    const oldJobs = [{ step: 'Sowing', ability: 'Grass', min_level: 1, seconds: 3 }, { step: 'Reaping', ability: 'Dark', min_level: 1, seconds: 3 }];
    for (const i of [1, 2]) {
        if (!Object.hasOwn(data, `event-${i}-name`)) continue;
        if (!data[`event-${i}-name`] && !Number(data[`event-${i}-count`]) && !data[`event-${i}-yield`]) {
            for (const field of productionOptionFields.filter(id => id.startsWith(`event-${i}-`))) delete data[field];
            continue;
        }
        try {
            if (JSON.stringify(JSON.parse(data[`event-${i}-jobs`])) === JSON.stringify(oldJobs)) {
                data[`event-${i}-jobs`] = JSON.stringify(defaultEventJobs(i - 1));
                if (Number(data[`event-${i}-watering-seconds`]) === 3) data[`event-${i}-watering-seconds`] = '6';
            }
        } catch { /* Older saves without a job list use the verified defaults. */ }
        data[`event-${i}-season-seed`] ??= '0'; data[`event-${i}-season-points`] ??= '0';
        if (!Object.hasOwn(data, `event-${i}-recipe`)) {
            const preset = [eventPreset(0), eventPreset(1)].find(p => translateEnglish(p.name) === translateEnglish(data[`event-${i}-name`]));
            data[`event-${i}-recipe`] = preset?.recipe || '';
        }
    }
    return data;
}
function applyEventPreset(i) {
    const crop = eventPreset(i - 1);
    const values = { name: eventTranslate(translateEnglish(crop.name)), recipe: crop.recipe || '', yield: crop.yield_amount, sell: crop.sell_value, seed: crop.seed_cost,
        'season-seed': crop.season_seed_cost, 'season-points': crop.season_points, 'growth-minutes': crop.growth_seconds / 60,
        'watering-level': crop.watering_level, 'watering-seconds': crop.watering_seconds,
        environment: crop.environment, description: eventTranslate(translateEnglish(crop.description)), jobs: JSON.stringify(crop.jobs) };
    for (const [field, value] of Object.entries(values)) document.getElementById(`event-${i}-${field}`).value = value;
    document.getElementById(`event-${i}-watering`).checked = crop.watering;
    renderJobFields(i);
}
function localizePresetValues() {
    for (const i of [1, 2]) {
        const preset = eventPreset(i - 1);
        for (const field of ['name', 'description']) {
            const element = document.getElementById(`event-${i}-${field}`);
            const english = translateEnglish(preset[field]);
            // Only recognizable preset values follow the language. Custom notes
            // and names, including Korean text in English mode, remain verbatim.
            if (element && translateEnglish(element.value) === english) element.value = eventTranslate(english);
        }
    }
}
function renderJobFields(i) {
    const jobs = storedJobs(i);
    document.getElementById(`event-${i}-job-rows`).innerHTML = Array.isArray(jobs) ? jobs.map((job, n) => `<div class="event-job-row" data-event="${i}" data-job="${n}">
        <label>작업명<input data-job-field="step" maxlength="50" value="${escapeHtml(eventTranslate(job.step))}"></label>
        <label>필요 능력<select data-job-field="ability">${EVENT_ABILITIES.map(a => `<option value="${a}"${a === job.ability ? ' selected' : ''}>${escapeHtml(eventTranslate(a))}</option>`).join('')}</select></label>
        <label>필요 레벨<input data-job-field="min_level" type="number" min="1" max="4" step="1" value="${escapeHtml(job.min_level)}"></label>
        <label>작업시간(초)<input data-job-field="seconds" type="number" min="0.01" max="86400" step="any" value="${escapeHtml(job.seconds)}"></label>
        <button type="button" class="toggle-button small" data-remove-event-job="${i}:${n}" aria-label="작업 삭제">삭제</button></div>`).join('') : '<p class="error">저장한 작업 목록을 읽을 수 없습니다. 일반 밭 예시를 불러와 다시 입력하세요.</p>';
}
export function mountEventFields(translate = value => value) {
    eventTranslate = translate;
    document.getElementById('event-crop-fields').innerHTML = [1, 2].map(i => `<div class="event-crop-card">
        <h4>이벤트 작물 ${i}</h4><label for="event-${i}-name">작물 이름</label><input id="event-${i}-name" maxlength="80" placeholder="이벤트 작물 ${i}">
        <label for="event-${i}-recipe">음식 재료로 연결할 작물</label><select id="event-${i}-recipe"><option value="">연결 없음 · 사용자 작물</option>${eventCropRecipes().map(r => `<option value="${escapeHtml(r.name)}">${escapeHtml(eventTranslate(r.game_name_en || r.name))}</option>`).join('')}</select>
        <button type="button" class="toggle-button small" data-event-preset="${i}">${escapeHtml(eventPreset(i - 1).name)} 게임 값으로 채우기</button>
        <label for="event-${i}-count">예약할 밭 칸 수</label><input id="event-${i}-count" type="number" min="0" step="1" value="0">
        <div class="event-economics">
            <label>1칸·1회 수확량(개)<input id="event-${i}-yield" type="number" min="1" step="1" placeholder="직접 입력"></label>
            <label>개당 판매가(홈코인)<input id="event-${i}-sell" type="number" min="0" step="any" placeholder="판매가 없으면 0"></label>
            <label>1칸·1회 씨앗 비용(홈코인)<input id="event-${i}-seed" type="number" min="0" step="any" placeholder="무료면 0"></label>
            <label><span>1칸·1회 씨앗 비용(<span class="event-seed-currency">${escapeHtml(translate(eventSeedCurrency))}</span>)</span><input id="event-${i}-season-seed" type="number" min="0" step="any" value="0"></label>
            <label>개당 시즌 포인트<input id="event-${i}-season-points" type="number" min="0" step="any" value="0"></label>
            <label>물주기 전 성장시간(분)<input id="event-${i}-growth-minutes" type="number" min="0.01" max="525600" step="any" value="40"></label>
        </div>
        <label class="event-watering-toggle"><input id="event-${i}-watering" type="checkbox" checked> 물주기 2회 적용 · 성장시간 25% 단축</label>
        <div class="event-economics event-watering-fields">
            <label>물 능력 필요 레벨<input id="event-${i}-watering-level" type="number" min="1" max="4" step="1" value="1"></label>
            <label>물주기 1회 작업시간(초)<input id="event-${i}-watering-seconds" type="number" min="0.01" max="86400" step="any" value="6"></label>
        </div>
        <p class="hint small" id="event-${i}-production-preview"></p>
        <details class="event-job-editor" open><summary>작업 애니모 직접 입력</summary>
            <p class="hint small">설치된 게임에서 확인: 땅 1 개간 5초, 풀 1 파종 3초·채집 3초, 물 1 관수 6초씩 2회. 해당 필요 레벨·성격 보너스 없는 기준이며 높은 능력의 속도는 계산에 반영합니다. 직접 수정할 수 있고, 물주기는 위 설정으로만 추가합니다. 작업을 모두 삭제하면 물주기 외 작업은 직접 수행합니다.</p>
            <input id="event-${i}-jobs" type="hidden"><div id="event-${i}-job-rows"></div>
            <div class="comparison-actions"><button type="button" class="toggle-button small" data-add-event-job="${i}">작업 추가</button><button type="button" class="toggle-button small" data-default-event-jobs="${i}">게임 재배 작업 복원</button></div>
        </details>
        <label for="event-${i}-environment">필수 환경 조건</label><select id="event-${i}-environment">
        <option value="">조건 없음</option><option value="Warm">따뜻함 · 난방</option><option value="Scorching">뜨거움 · 난방</option>
        <option value="Cool">차가움 · 냉방</option><option value="Freeze">빙결 · 냉방</option><option value="Adequate">충분 · 조명</option></select>
        <label for="event-${i}-description">환경·재배 설명 (메모)</label><textarea id="event-${i}-description" rows="2" maxlength="1500" placeholder="예: 차가운 환경을 계속 유지"></textarea>
        </div>`).join('');
    for (const i of [1, 2]) applyEventPreset(i);
    const fields = document.getElementById('event-crop-fields');
    const saveJobs = (i, jobs) => {
        const input = document.getElementById(`event-${i}-jobs`); input.value = JSON.stringify(jobs); input.dispatchEvent(new Event('input', { bubbles: true }));
    };
    fields.addEventListener('input', event => {
        const field = event.target.dataset.jobField, row = event.target.closest('[data-event][data-job]');
        if (!field || !row) return;
        const jobs = storedJobs(row.dataset.event); if (!Array.isArray(jobs)) return;
        jobs[Number(row.dataset.job)][field] = ['min_level', 'seconds'].includes(field) ? Number(event.target.value) : event.target.value;
        saveJobs(row.dataset.event, jobs);
    });
    fields.addEventListener('click', event => {
        const preset = event.target.closest('[data-event-preset]');
        if (preset) { const i = Number(preset.dataset.eventPreset); applyEventPreset(i); document.getElementById(`event-${i}-name`).dispatchEvent(new Event('input', { bubbles: true })); return; }
        const button = event.target.closest('[data-add-event-job],[data-remove-event-job],[data-default-event-jobs]'); if (!button) return;
        const remove = button.dataset.removeEventJob?.split(':');
        const i = remove?.[0] || button.dataset.addEventJob || button.dataset.defaultEventJobs;
        let jobs = storedJobs(i); if (!Array.isArray(jobs)) jobs = [];
        if (remove) jobs.splice(Number(remove[1]), 1);
        else if (button.dataset.defaultEventJobs) {
            jobs = defaultEventJobs(Number(i) - 1);
            const preset = eventPreset(Number(i) - 1);
            document.getElementById(`event-${i}-watering-level`).value = preset.watering_level;
            document.getElementById(`event-${i}-watering-seconds`).value = preset.watering_seconds;
        }
        else if (jobs.length < 12) jobs.push({ step: '추가 작업', ability: 'Grass', min_level: 1, seconds: 3 });
        saveJobs(i, jobs); renderJobFields(i);
    });
}
export function readEventCrops() {
    if (!document.getElementById('event-1-name')) return [];
    const number = id => { const value = document.getElementById(id).value.trim(); return value === '' ? null : Number(value); };
    return [1, 2].map(i => {
        const count = Number(document.getElementById(`event-${i}-count`).value);
        const watering = document.getElementById(`event-${i}-watering`).checked;
        const waterNumber = (field, fallback) => number(`event-${i}-${field}`) ?? (count > 0 && watering ? null : fallback);
        return { name: document.getElementById(`event-${i}-name`).value.trim(), recipe: document.getElementById(`event-${i}-recipe`).value || null, count,
        environment: document.getElementById(`event-${i}-environment`).value || null,
        description: document.getElementById(`event-${i}-description`).value.trim(),
        yield_amount: number(`event-${i}-yield`), sell_value: number(`event-${i}-sell`), seed_cost: number(`event-${i}-seed`),
        season_seed_cost: number(`event-${i}-season-seed`) ?? 0, season_points: number(`event-${i}-season-points`) ?? 0,
        growth_seconds: number(`event-${i}-growth-minutes`) * 60, watering,
        watering_level: waterNumber('watering-level', 1), watering_seconds: waterNumber('watering-seconds', 6), jobs: storedJobs(i) };
    });
}
const signature = input => JSON.stringify(input, (key, value) => value && typeof value === 'object' && !Array.isArray(value)
    ? Object.fromEntries(Object.keys(value).sort().map(k => [k, key === '' && k === 'aniimo' ? value[k]?.split(':')[0] : value[k]])) : value);

export function createProductionOptionsUI(api) {
    const byId = id => document.getElementById(id), esc = api.escapeText;
    const text = name => api.translate(findEventCrop(name, comparison?.input.event_crops)?.name || api.prettyItem(name));
    [1, 2].forEach(renderJobFields);
    const fmt = value => Number(value).toLocaleString('ko-KR', { maximumFractionDigits: 3 });
    const signed = value => Math.abs(value) < 0.0005 ? '0' : (value > 0 ? '+' : '') + fmt(value);
    let cache = null, comparison = null, run = 0, solver = null, rejectPending = null;
    const result = document.createElement('section'); result.id = 'recipe-comparison'; result.className = 'card'; result.hidden = true;
    document.querySelector('.config-section').after(result);
    function status(message) { byId('recipe-maximize-status').textContent = message; }
    function cancel(message = '계산을 취소했습니다.') {
        const running = !!solver;
        run++; solver?.terminate(); solver = null; rejectPending?.(new Error(message)); rejectPending = null;
        byId('recipe-maximize-btn').disabled = false; byId('recipe-cancel-btn').hidden = true;
        if (running) byId('optimize-btn').disabled = false;
    }
    function solve(type, input, target, ticket, caption) {
        return new Promise((resolve, reject) => {
            rejectPending = reject; solver = api.createSolverWorker();
            solver.onerror = event => { solver?.terminate(); solver = null; rejectPending = null; reject(new Error(event.message || '계산기가 중단되었습니다.')); };
            solver.onmessage = ({ data }) => {
                if (data.id !== 1 || ticket !== run) return;
                if (data.type === 'progress') { status(`${caption} · ${data.count?.step === 'recipe_income' ? '남은 시설의 홈코인 계산' : '시설·재료·환경 조건 계산'} 중… 각 탐색의 제한은 ${(input.solver_time_limit ?? 180) / 60}분입니다.`); return; }
                solver.terminate(); solver = null; rejectPending = null;
                if (!data.ok) { reject(new Error(data.error)); return; }
                const plan = JSON.parse(data.result);
                if (!plan.success) reject(new Error(plan.error)); else resolve(plan);
            };
            solver.postMessage({ id: 1, type, payload: JSON.stringify(type === 'maximize_recipe' ? { input, target } : input) });
        });
    }
    function renderComparison() {
        const c = comparison;
        if (!c) return;
        result.hidden = false;
        if (!c.baseline) {
            result.innerHTML = `<h2>${esc(text(c.target))} 생산 계획</h2><p>확보량 ${fmt(c.candidate.recipe_target.net_per_second * 3600)}개/시간 · ${c.candidate.recipe_target.proven_optimal ? '최대 생산량 확인 완료' : '최대치 확정 전'}</p>
                <p>최대 생산 계획은 확보했지만, 같은 조건의 기존 전략 계산을 완료하지 못해 수량 차이는 표시하지 않습니다.</p><p class="hint">${esc(c.baselineError)}</p>
                <button type="button" data-show-plan="candidate">선택 레시피의 상세 계획·배치도</button><p id="comparison-showing" role="status"></p>`;
            result.querySelector('button').addEventListener('click', () => show('candidate'));
            return;
        }
        const rows = compareProduction(c.baseline, c.candidate, withEventRecipes(api.recipes(), c.input.event_crops));
        const before = Math.max(0, rows.before.net.get(c.target) || 0) * 3600;
        const after = c.candidate.recipe_target.net_per_second * 3600;
        const proof = c.candidate.recipe_target.proven_optimal;
        result.innerHTML = `<h2>${esc(text(c.target))} 최대 생산 비교</h2>
            <p>${c.input.production_mode === 'flexible' ? `병행 생산 · 밭·숲지 고정 · 시설당 최대 ${recipeLimit(c.input)}개 레시피` : '단일 생산 · 시설마다 레시피 고정'}</p>
            <p class="hint">${proof ? '최대 생산량 확인 완료' : '제한 시간 안에 찾은 생산량 · 최대치 확정 전'}${!proof ? ` / 이론 상한 ${fmt(c.candidate.recipe_target.upper_bound * 3600)}개/시간` : ''}. 재료로 소비하고 남는 수량입니다. 같은 생산량의 계획은 홈코인으로 비교하며, 계산 오차 허용 범위는 0.01%입니다.</p>
            ${c.candidate.recipe_income_note ? `<p class="hint">${esc(c.candidate.recipe_income_note)}</p>` : ''}
            <div class="comparison-scroll"><table><thead><tr><th>비교 항목</th><th>기존 전략</th><th>선택 레시피 우선</th><th>차이</th></tr></thead><tbody>
            <tr><th>${esc(text(c.target))} 확보량/시간</th><td>${fmt(before)}</td><td>${fmt(after)}</td><td>${signed(after - before)}</td></tr>
            <tr><th>홈코인/시간</th><td>${fmt(c.baseline.rate_per_second * 3600)}</td><td>${fmt(c.candidate.rate_per_second * 3600)}</td><td>${signed((c.candidate.rate_per_second - c.baseline.rate_per_second) * 3600)}</td></tr>
            </tbody></table></div>
            <p class="hint">홈코인은 남은 생산물을 판매했을 때의 수익입니다. 선택 생산물을 보관하면 해당 판매 수익은 얻지 않습니다. 이벤트 작물의 판매 수익·씨앗 비용·입력한 애니모 작업을 포함합니다. 기존 계획${c.baseline.proven_optimal === true ? '은 최적값 확인 완료' : '은 제한 시간 내 확보한 계획'}입니다.</p>
            <div class="comparison-actions"><button type="button" class="toggle-button" data-show-plan="baseline">기존 전략의 상세 계획·배치도</button><button type="button" class="toggle-button" data-show-plan="candidate">선택 레시피의 상세 계획·배치도</button></div>
            <p id="comparison-showing" role="status"></p>
            <details open><summary>상세 레시피 생산량 차이 · 개/시간 (재료 사용 전)</summary><div class="comparison-scroll"><table><thead><tr><th>레시피</th><th>기존 전략</th><th>선택 레시피 우선</th><th>차이</th></tr></thead><tbody>${rows.rows.sort((a,b) => text(a.name).localeCompare(text(b.name))).map(r => `<tr><th>${esc(text(r.name))}</th><td>${fmt(r.before)}</td><td>${fmt(r.after)}</td><td>${signed(r.delta)}</td></tr>`).join('')}</tbody></table></div></details>`;
        result.querySelectorAll('[data-show-plan]').forEach(button => button.addEventListener('click', () => show(button.dataset.showPlan)));
    }
    function show(which) {
        if (!comparison) return;
        const c = comparison, plan = which === 'candidate' ? c.candidate : c.baseline;
        api.showPlan(plan, c.input, { ...c.context, levelUp: which === 'candidate' ? false : c.context.levelUp });
        byId('comparison-showing').textContent = `아래 상세 계획: ${which === 'candidate' ? '선택 레시피 우선' : '기존 전략'}`;
    }
    async function maximize() {
        cancel(); const ticket = run;
        comparison = null; result.hidden = true;
        try {
            const recipes = api.recipes().filter(r => !isEvent(r.name));
            if (!recipes.length) throw new Error('레시피 데이터를 불러오는 중입니다. 잠시 후 다시 계산하세요.');
            const query = translateEnglish(byId('recipe-target-input').value.trim()).toLowerCase();
            const matches = recipes.filter(r => [r.name, text(r.name), api.recipeLabel(r)].some(value => translateEnglish(value).toLowerCase() === query));
            if (matches.length !== 1) throw new Error('목록에서 최대로 생산할 레시피를 하나 선택하세요.');
            const target = productOf(matches[0].name, recipes), input = api.getInput(), context = api.getContext(input);
            validateEvents(input.event_crops || [], (input.facilities.Farmland || []).reduce((n,t) => n+t.count,0));
            const blockers = recipeBlockers(target, input, recipes);
            if (blockers.length) throw new Error('현재 설정에서는 생산 불가: ' + blockers.map(reason => {
                let label = reason;
                const names = new Set(recipes.map(r => r.name));
                label = label.replace(/\b[a-z0-9_]+\b/g, name => names.has(name) ? text(name) : name);
                for (const facility of new Set(recipes.map(r => r.facility))) label = label.replaceAll(facility, api.translate(facility));
                for (const [raw, name] of Object.entries({ ecological_module: 'Ecological Module', kitchen_module: 'Kitchen Module', resource_detector: 'Resource Detector', crafting_module: 'Crafting Module' })) label = label.replaceAll(raw, api.translate(name));
                return api.translate(label);
            }).slice(0, 12).join(' / '));
            api.onStart(); byId('recipe-maximize-btn').disabled = true; byId('recipe-cancel-btn').hidden = false; byId('optimize-btn').disabled = true;
            status('선택 레시피의 최대 생산량 계산 중…');
            let candidate = await solve('maximize_recipe', input, target, ticket, '선택 레시피 최대 생산');
            if (ticket !== run) return;
            if (!(candidate.recipe_target?.net_per_second > 1e-9)) {
                if (!candidate.recipe_target?.proven_optimal) throw new Error('제한 시간 안에 생산 가능한 계획을 찾지 못했습니다. 생산 불가로 확정하지 않았습니다.');
                if (input.production_mode === 'single') {
                    const flexible = await solve('maximize_recipe', { ...input, production_mode: 'flexible', recipe_diagnostic: true }, target, ticket, '단일 생산 불가 · 병행 생산 가능 여부 확인');
                    if (flexible.recipe_target?.net_per_second > 1e-9) throw new Error(`단일 생산에서는 생산 불가: 원재료·중간재·완제품에 필요한 레시피를 시설별로 고정할 수 없습니다. 병행 생산으로 교대하면 ${fmt(flexible.recipe_target.net_per_second * 3600)}개/시간 계획이 가능합니다. 생산 방식은 단일 생산으로 유지했습니다.`);
                    if (!flexible.recipe_target?.proven_optimal) throw new Error('단일 생산에서는 생산 불가입니다. 병행 생산의 가능 여부는 제한 시간 안에 확정하지 못했습니다.');
                }
                throw new Error('현재 조건에서는 생산 불가: 원재료부터 완제품까지 시설 수·레벨·애니모·환경 조건을 동시에 만족할 수 없습니다. 병행 생산도 밭·숲지 고정 및 시설당 두 레시피 제한을 적용합니다.');
            }
            status('같은 조건으로 기존 전략의 계획을 계산해 비교하는 중…');
            let baseline;
            try { baseline = cache?.key === signature(input) ? cache.plan : await solve('find_plan', input, null, ticket, '기존 전략 비교'); }
            catch (error) {
                if (ticket !== run) return;
                comparison = { candidate, baseline: null, baselineError: error.message, input, target, context };
                renderComparison(); show('candidate'); status('최대 생산 계획을 표시했습니다. 기존 전략 계산이 완료되지 않아 차이 비교는 미완료입니다.');
                return;
            }
            if (ticket !== run) return;
            const existingRate = productionRates(baseline, withEventRecipes(recipes, input.event_crops)).net.get(target) || 0;
            if (existingRate > candidate.recipe_target.net_per_second + 1e-7) {
                candidate = { ...baseline, recipe_target: { ...candidate.recipe_target, net_per_second: existingRate,
                    proven_optimal: false, upper_bound: Math.max(existingRate, candidate.recipe_target.upper_bound) },
                    recipe_income_note: '기존 전략에서 더 많은 생산량을 확보해 그 계획을 유지했습니다. 최대치 확정 전입니다.', proven_optimal: null, upper_bound: null };
            }
            comparison = { candidate, baseline, input, target, context };
            cache = { key: signature(input), plan: baseline };
            renderComparison(); show('candidate'); status('비교 완료. 아래에서 기존 계획과 최대 생산 계획의 상세 배치도를 전환할 수 있습니다.');
            result.scrollIntoView({ block: 'start', behavior: 'smooth' });
        } catch (error) { if (ticket === run) status(error.message); }
        finally { if (ticket === run) { byId('recipe-maximize-btn').disabled = false; byId('recipe-cancel-btn').hidden = true; byId('optimize-btn').disabled = false; } }
    }
    function updateSummary() {
        for (const [index, crop] of readEventCrops().entries()) {
            const cycle = eventCycle(crop), output = crop.count * crop.yield_amount * 3600 / cycle;
            let message = `실제 성장시간 ${fmt(cycle / 60)}분${crop.watering ? ' · 물주기 2회' : ' · 물주기 없음'}`;
            if (crop.count > 0 && crop.yield_amount != null && crop.sell_value != null && crop.seed_cost != null && cycle > 0) {
                const income = crop.count * 3600 / cycle * (crop.yield_amount * crop.sell_value - crop.seed_cost);
                message += ` · ${fmt(output)}개/시간 · 전량 판매 시 씨앗 차감 후 ${fmt(income)}홈코인/시간`;
                if (crop.season_seed_cost > 0) message += ` · 씨앗 ${fmt(crop.count * 3600 / cycle * crop.season_seed_cost)}${eventTranslate(eventSeedCurrency)}/시간 별도 소모`;
            }
            byId(`event-${index + 1}-production-preview`).textContent = message;
            byId(`event-${index + 1}-watering-level`).disabled = !crop.watering;
            byId(`event-${index + 1}-watering-seconds`).disabled = !crop.watering;
        }
        api.eventsChanged?.();
        try {
            const input = api.getInput(), { total, reserved, ordinary } = validateEvents(input.event_crops || [], (input.facilities.Farmland || []).reduce((n,t) => n+t.count,0), { economics: false });
            byId('event-farmland-summary').textContent = `전체 밭 ${total}칸 − 이벤트 밭 ${reserved}칸 = 일반 생산용 밭 ${ordinary}칸`;
        } catch (error) { byId('event-farmland-summary').textContent = error.message; }
    }
    function invalidate() {
        if (solver) { cancel(); status('설정이 바뀌어 비교 계산을 취소했습니다. 새 설정으로 다시 계산하세요.'); }
        if (comparison) { comparison = null; result.hidden = true; status('설정이 바뀌었습니다. 새 조건으로 다시 비교하세요.'); }
        queueMicrotask(updateSummary);
    }
    byId('recipe-maximize-btn').addEventListener('click', maximize);
    byId('recipe-target-input').addEventListener('keydown', event => {
        if (event.key === 'Enter') { event.preventDefault(); maximize(); }
    });
    byId('recipe-cancel-btn').addEventListener('click', () => { cancel(); status('계산을 취소했습니다.'); });
    document.querySelector('.config-section').addEventListener('input', invalidate);
    document.querySelector('.config-section').addEventListener('change', invalidate);
    document.querySelector('.config-section').addEventListener('click', event => {
        if (event.target.closest('.add-tier-btn,.tier-remove-btn,[data-move],[data-unskip],#skip-add-btn')) invalidate();
    });
    document.getElementById('aniimo-setup-panel').addEventListener('change', invalidate);
    byId('fill-btn').addEventListener('click', invalidate);
    return { updateSummary, cancel, invalidate,
        remember(plan, input) { if (plan?.success && !plan.recipe_target) cache = { key: signature(input), plan }; },
        renderOptions() {
            localizePresetValues();
            [1, 2].forEach(renderJobFields);
            const input = byId('recipe-target-input'), options = byId('recipe-target-options');
            const selected = [...options.options].find(o => translateEnglish(o.value) === translateEnglish(input.value))?.dataset.name
                || api.recipes().find(r => translateEnglish(api.recipeLabel(r)) === translateEnglish(input.value))?.name;
            options.innerHTML = api.recipes().filter(r => !isEvent(r.name)).map(r => `<option data-name="${esc(r.name)}" value="${esc(api.recipeLabel(r))}"></option>`).join('');
            if (selected) input.value = [...options.options].find(o => o.dataset.name === selected)?.value || input.value;
        },
    };
}
