import { SPECIAL_RECIPES } from './base-facility-config.js';
const legacy = new Set(SPECIAL_RECIPES.map(r => r.name));
export const requiresRecipeUnlock = recipe => recipe.special_unlock ?? (!!recipe.unlock_item_id || legacy.has(recipe.name));
export const recipeRVAvailable = (recipe, level) => (recipe.min_rv_level || 1) <= level;
export const unlockRecipes = (recipes, season = false) => recipes.filter(r => !!r.season === season
    && !(season && r.facility === 'Farmland') && requiresRecipeUnlock(r))
    .map(r => ({ name: r.name, facility: r.facility, min_rv_level: r.min_rv_level }));
