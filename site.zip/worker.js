// Web Worker hosting the wasm optimizer and the HiGHS solver. Solving can take long enough that
// running it on the main thread would freeze the page's own rendering, which is what makes the
// browser offer to kill the tab; every wasm call is dispatched through here instead, so the main
// thread stays free to paint a progress indicator while a solve is in flight. See `web/app.js`'s
// `callWorker` for the request/response contract this expects.
import highsModule from './vendor/highs/highs.mjs';
import { solverFailureMessage } from './solver-status.js';
import { solveOptionsFor } from './solver-settings.js';
import { solverPriorities, recipeMaxPriorities, isSalesProfit } from './sales-profit.js';

// The page starts this worker as `worker.js?load=<page load time>` (see app.js), and the wasm
// module is loaded with the same query and a revalidated fetch, so a page never pairs new page
// code with an older cached solver.
// The message handler below is installed right away and waits on this, so no request can arrive
// before there's a handler for it.
const load = new URL(import.meta.url).search;
const ready = import('./pkg/aniimax.js' + load).then(async (pkg) => {
    await pkg.default({ module_or_path: fetch(new URL('./pkg/aniimax_bg.wasm', import.meta.url), { cache: 'no-cache' }) });
    return pkg;
});

// Handlers taking a single string argument and returning one; `find_plan` and
// `rank_improvements` are handled separately below since they report progress.
const HANDLER_NAMES = ['time_to_reach', 'get_version', 'get_all_items', 'set_catalog'];

// HiGHS (https://highs.dev), compiled to WebAssembly. A fresh instance per solve, from bytes
// fetched once, so one failed solve can't leave a broken instance behind for the next.
let highsBytes = null;
async function newHighs() {
    if (!highsBytes) {
        highsBytes = fetch(new URL('./vendor/highs/highs.wasm', import.meta.url)).then(r => {
            if (!r.ok) throw new Error(`Could not load HiGHS (${r.status})`);
            return r.arrayBuffer();
        });
    }
    return highsModule({ wasmBinary: await highsBytes, print: () => {}, printErr: line => console.warn(line) });
}

// Seconds HiGHS may search before settling for the best plan found so far.
const SOLVE_OPTIONS = solveOptionsFor();

// A tighter feasibility tolerance, used only to solve again when the plan built from an answer
// doesn't hold up: HiGHS can otherwise lean on rounding noise, a hair of negative production
// making something from nothing (seen at RV 9 with Coins then Aniimo EXP). It isn't the default
// because on a big model it can have HiGHS call a perfectly feasible plan infeasible (seen on the
// RV 17 level-up).

// Solves one exact-planner model with HiGHS: `{ values, proven, objective }`, or null if HiGHS
// found no plan at all. `objective` leaves out the model's tie-break (see `BUILDING_TIE_BREAK` in
// exact.rs), so it's what the plan really makes and can be a floor for a later solve.
async function solveModel(problem, options = SOLVE_OPTIONS) {
    delete problem.solve_failure;
    let result = (await newHighs()).solve(problem.lp, options);
    if (result.Status === 'Infeasible') {
        // HiGHS's presolve can call a tightly constrained model infeasible when it isn't (seen on
        // the level-up stock solve, whose floors come from earlier solves); solving without it
        // settles it.
        result = (await newHighs()).solve(problem.lp, { ...options, presolve: 'off' });
    }
    const proven = result.Status === 'Optimal';
    const failed = () => {
        problem.solve_failure = { status: result.Status, time_limit: options.time_limit };
        return null;
    };
    if (!proven && result.Status !== 'Time limit reached') return failed();
    // Out of time before finding any plan at all.
    if (!Number.isFinite(result.ObjectiveValue) || !result.Columns) return failed();
    const values = columnValues(problem, result);
    return { values, proven, objective: result.ObjectiveValue + tiebreakOf(problem, values) };
}

function columnValues(problem, result) {
    return Array.from({ length: problem.variables }, (_, i) => result.Columns?.['x' + i]?.Primal ?? 0);
}

// What the model's tie-break (see `BUILDING_TIE_BREAK` in exact.rs) took off an objective.
function tiebreakOf(problem, values) {
    return (problem.tiebreak || []).reduce((sum, [v, weight]) => sum + weight * (values[v] || 0), 0);
}

// The exact planner (see `exact_problem` in wasm.rs): builds the model in wasm, solves it with
// HiGHS, and turns the answer back into a plan. With "prioritize byproducts" on, it first finds
// the most of each byproduct the facilities can make and requires the plan to keep that much.
// With priorities (coins, Aniimo EXP, Aniipods, Wood Blocks, Mineral Sand), it makes as much of
// each as the ones before it allow, then earns coins with what's left.
// For the level-up strategy, it first finds the soonest level-up and requires the plan to keep
// that pace; if the facilities can't make the level-up at all, the plan is for coins and says so.
// Returns the plan's JSON, or throws with the reason it couldn't, so the caller can fall back to
// `find_plan` and say why. `step(key, state, proven)` reports each solve as it starts and ends,
// and whether it proved its answer, for the page's progress card: `priority:<target>`,
// `level_up`, `final`, `stock_up` and `check`. `first(top)` gets the plan's first solve with
// nothing before it, `{ measure, objective, proven }`: the most of its first priority, its
// level-up pace, or its Home Coins. The page's Opportunities solve that same model for the plan
// as it stands, so they take it from here.
async function exactPlanJson(pkg, payload, step = () => {}, first = () => {}, floors = [], { prioritiesResolved = false, onPriorities = () => {} } = {}) {
    const { exact_byproduct_problems, exact_priority_problem, exact_level_up_problem, exact_problem, exact_plan } = pkg;
    const stage = { floors: [...floors] };
    const input = JSON.parse(payload);
    input.priorities = solverPriorities(input.priorities || []);
    payload = JSON.stringify(input);
    const options = solveOptionsFor(input);
    const validation = JSON.parse(pkg.validate_plan_input(payload));
    if (!validation.success) throw new Error(validation.error);
    const currency = input.currency || 'coins';
    let lastCurrencySolve = null;
    let allProven = true;
    let levelUpNote = null;
    const rankedLevelUp = input.priorities.includes('level_up');
    for (const problem of prioritiesResolved ? [] : JSON.parse(exact_byproduct_problems(payload))) {
        const most = await solveModel(problem, options);
        if (!most) throw new Error(solverFailureMessage(problem, `${problem.resource} 최대 생산량 계산`));
        allProven &&= most.proven;
        stage.floors.push([problem.resource, most.objective]);
    }
    // The player's priorities, in order: each is made as much as the ones before it allow, and
    // the coin solve after them has to keep all of it up.
    for (const target of prioritiesResolved ? [] : input.priorities) {
        step(`priority:${target}`, 'start');
        const alone = stage.floors.length === 0 && !stage.pace;
        const before = JSON.stringify(stage);
        if (target === 'level_up' && !input.level_up) throw new Error('Choose a target RV with known level-up costs for the Level up priority.');
        const priority = JSON.parse(exact_priority_problem(payload, before, target));
        if (target === 'level_up' && !priority.lp && input.level_up.cost.every(([name, need]) =>
            (input.level_up.stock || []).filter(([item]) => item === name).reduce((sum, [, have]) => sum + have, 0) >= need)) {
            step(`priority:${target}`, 'done', true); continue;
        }
        if (!priority.lp) throw new Error('this setup isn\'t covered by the exact planner');
        const most = await solveModel(priority, options);
        step(`priority:${target}`, 'done', most?.proven);
        if (!most) throw new Error(solverFailureMessage(priority, `${target} 우선순위 계산`));
        if (alone) first({ measure: target, objective: most.objective, proven: most.proven });
        allProven &&= most.proven;
        if (target === 'level_up') {
            lastCurrencySolve = null;
            if (most.objective > 1e-9) stage.pace = most.objective;
            else levelUpNote = !most.proven ? 'unconfirmed' : stage.floors.length ? 'unreachable_with_priorities' : 'unreachable';
            continue;
        }
        // If the final priority is already the target currency, it is exactly the final
        // solve. Retain its model AND stage so values never cross variable orderings.
        // Adding its own score as a new floor and starting again can time out without an
        // incumbent, losing the feasible result just found (RV20: Wood, Sand, Coins).
        lastCurrencySolve = target === currency ? { problem: priority, stageJson: before, solved: most } : null;
        stage.floors.push([target, most.objective]);
    }

    onPriorities(stage.floors.map(floor => [...floor]));
    const levelUp = rankedLevelUp ? {} : JSON.parse(exact_level_up_problem(payload));
    if (levelUp.lp) {
        step('level_up', 'start');
        const fastest = await solveModel(levelUp, options);
        step('level_up', 'done', fastest?.proven);
        if (!fastest) throw new Error(solverFailureMessage(levelUp, '레벨업 계산'));
        if (stage.floors.length === 0) first({ measure: 'level_up', objective: fastest.objective, proven: fastest.proven });
        if (fastest.objective > 1e-9) {
            allProven &&= fastest.proven;
            stage.pace = fastest.objective;
        } else {
            levelUpNote = 'unreachable';
        }
    }
    const reuse = !levelUp.lp ? lastCurrencySolve : null;
    let stageJson = reuse ? reuse.stageJson : JSON.stringify(stage);
    let problem = reuse ? reuse.problem : JSON.parse(exact_problem(payload, stageJson));
    if (!problem.lp) throw new Error('this setup isn\'t covered by the exact planner');
    step('final', 'start');
    const alone = stage.floors.length === 0 && !stage.pace;
    let solved = reuse ? reuse.solved : await solveModel(problem, options);
    if (!solved) throw new Error(solverFailureMessage(problem, '최종 수익 계산'));
    if (alone) first({ measure: currency, objective: solved.objective, proven: solved.proven });
    let proven = solved.proven && allProven;
    let bound = solved.objective;
    if (!proven) {
        // The same model without whole units: the most any plan could earn.
        const relaxed = (await newHighs()).solve(problem.lp.replace(/\nGeneral\n[\s\S]*\nEnd/, '\nEnd'), options);
        if (relaxed.Status === 'Optimal' && Number.isFinite(relaxed.ObjectiveValue)) {
            bound = Math.max(bound, relaxed.ObjectiveValue + tiebreakOf(problem, columnValues(problem, relaxed)));
        } else bound = null;
    }
    step('final', 'done', solved.proven);
    if (stage.pace) {
        // Keeping that pace and those coins, spare Bench and Kiln time goes to the level-up. If
        // that solve fails, the plan above already has the pace and coins, so it stands.
        const stockStage = { ...stage, coins: solved.objective };
        const stockJson = JSON.stringify(stockStage);
        step('stock_up', 'start');
        const stocked = await solveModel(JSON.parse(exact_problem(payload, stockJson)), options);
        step('stock_up', 'done', stocked?.proven);
        step('check', 'start');
        const stockedPlan = stocked
            && JSON.parse(exact_plan(payload, stockJson, JSON.stringify({ values: stocked.values, proven: proven && stocked.proven, bound })));
        if (stockedPlan && stockedPlan.success) {
            step('check', 'done');
            stockedPlan.level_up_note = levelUpNote;
            return JSON.stringify(stockedPlan);
        }
        console.warn('Level-up stock solve found no usable plan; keeping the plan without it.');
    }
    step('check', 'start');
    let json = exact_plan(payload, stageJson, JSON.stringify({ values: solved.values, proven, bound }));
    let plan = JSON.parse(json);
    if (!plan.success) {
        // The answer didn't survive being rebuilt exactly; solve again, this time refusing the
        // rounding noise it may have leaned on.
        const strict = await solveModel(problem, solveOptionsFor(input, true));
        if (strict) {
            json = exact_plan(payload, stageJson, JSON.stringify({ values: strict.values, proven: strict.proven && allProven, bound }));
            plan = JSON.parse(json);
        }
    }
    if (!plan.success) throw new Error(plan.error || 'the plan failed its check');
    step('check', 'done');
    if (!levelUpNote) return json;
    plan.level_up_note = levelUpNote;
    return JSON.stringify(plan);
}

// Ranks changes the player could make (see `rankImprovements` in app.js). `payload` is
// `{ measure, base, candidates }`: `measure` is the priority target the plan leads with, or
// 'level_up' for the soonest level-up; `base` and each candidate are plan inputs. Each input's
// best `measure` is solved, and where that doesn't move, the most Home Coins while keeping it.
// Reports one `{ index, top, coins, proven }` per input as it goes, the base first (index -1).
async function rankImprovements(pkg, payload, report) {
    const { measure, base, candidates, baseTop: given } = JSON.parse(payload);
    const topOf = async (input) => {
        const json = JSON.stringify(input);
        const problem = JSON.parse(measure === 'level_up'
            ? pkg.exact_level_up_problem(json)
            : pkg.exact_priority_problem(json, JSON.stringify({ floors: [] }), measure));
        if (!problem.lp) return null;
        return solveModel(problem, solveOptionsFor(input));
    };
    // Home Coins while keeping `top` of the measure; the same solve the plan itself runs next.
    const coinsAt = async (input, top) => {
        if (measure === 'coins') return null;
        const json = JSON.stringify(input);
        const problem = JSON.parse(measure === 'level_up'
            ? pkg.exact_problem(json, JSON.stringify({ floors: [], pace: top }))
            : pkg.exact_priority_problem(json, JSON.stringify({ floors: [[measure, Math.max(0, top)]] }), 'coins'));
        if (!problem.lp) return null;
        return solveModel(problem, solveOptionsFor(input));
    };
    // The plan as it stands was solved just now; the page passes that on when it can.
    const baseTop = given?.measure === measure ? given : await topOf(base);
    if (!baseTop) {
        report({ index: -1, top: null });
        return;
    }
    let baseCoins;
    report({ index: -1, top: baseTop.objective, proven: baseTop.proven });
    for (const [index, input] of candidates.entries()) {
        const top = await topOf(input);
        if (!top) {
            report({ index, top: null });
            continue;
        }
        let coins = null;
        let proven = top.proven;
        // Only when the measure itself doesn't move does the Home Coins tiebreak matter.
        if (measure !== 'coins' && top.objective <= baseTop.objective * (1 + RANK_MIN_GAIN)) {
            if (baseCoins === undefined) baseCoins = await coinsAt(base, baseTop.objective);
            const candidateCoins = await coinsAt(input, top.objective);
            if (baseCoins && candidateCoins) {
                coins = { base: baseCoins.objective, value: candidateCoins.objective };
                proven &&= baseCoins.proven && candidateCoins.proven;
            }
        }
        report({ index, top: top.objective, coins, proven });
    }
}

// The smallest gain worth ranking, as a share of what the plan already makes: below it, a
// difference is as likely to be the solver's tolerances as a real improvement.
const RANK_MIN_GAIN = 1e-3;

let catalogError = null;
self.onmessage = async (event) => {
    const { id, type, payload } = event.data;
    try {
        const pkg = await ready;
        if (catalogError && type !== 'set_catalog') throw catalogError;
        if (type === 'maximize_recipe') {
            const { input, target } = JSON.parse(payload);
            const step = (key, state, proven) => self.postMessage({ id, type: 'progress', count: { step: key, state, proven } });
            // Keep non-income priorities first; a coin floor can prevent any target output.
            // This copy leaves ordinary calculation and the saved selection unchanged.
            // Retain those ORIGINAL floors during the income tie-break; re-solving or using
            // the already-relaxed output would weaken the earlier priorities a second time.
            const targetInput = { ...input, currency: `recipe:${target}`, level_up: null,
                priorities: recipeMaxPriorities(input.priorities || []) };
            let priorityFloors = [];
            const maximum = JSON.parse(await exactPlanJson(pkg, JSON.stringify(targetInput), step, () => {}, [],
                { onPriorities: floors => { priorityFloors = floors; } }));
            maximum.recipe_target.priority_floors = priorityFloors;
            maximum.recipe_target.excluded_priorities = (input.priorities || []).filter(isSalesProfit);
            if (maximum.recipe_target?.net_per_second > 1e-9 && !input.recipe_diagnostic) {
                try {
                    step('recipe_income', 'start');
                    const refined = JSON.parse(await exactPlanJson(pkg, JSON.stringify({ ...targetInput, currency: 'coins' }), step,
                        () => {}, [...priorityFloors, [`recipe:${target}`, maximum.recipe_target.net_per_second]], { prioritiesResolved: true }));
                    refined.recipe_target = { ...maximum.recipe_target, net_per_second: refined.recipe_target.net_per_second };
                    refined.proven_optimal = null; refined.upper_bound = null;
                    self.postMessage({ id, ok: true, result: JSON.stringify(refined) });
                    return;
                } catch (error) {
                    maximum.recipe_income_note = `남은 시설의 홈코인 최적화는 완료하지 못해, 확보한 최대 생산 계획을 표시합니다: ${error.message}`;
                }
            }
            self.postMessage({ id, ok: true, result: JSON.stringify(maximum) });
            return;
        }
        if (type === 'rank_improvements') {
            await rankImprovements(pkg, payload, (result) => self.postMessage({ id, type: 'progress', count: result }));
            self.postMessage({ id, ok: true, result: null });
            return;
        }
        if (type === 'find_plan') {
            let result = null;
            let fallbackReason = null;
            // Each solve's start and end go to the page as progress, as `{ step, state, proven }`.
            const step = (key, state, proven) => self.postMessage({ id, type: 'progress', count: { step: key, state, proven } });
            try {
                let top = null;
                result = await exactPlanJson(pkg, payload, step, found => { top ||= found; });
                if (top) {
                    const plan = JSON.parse(result);
                    plan.measure_top = top;
                    result = JSON.stringify(plan);
                }
            } catch (error) {
                fallbackReason = error && error.message ? error.message : String(error);
                // The backup planner doesn't know the player's roster, so a roster plan stops here.
                if (JSON.parse(payload).production_mode || JSON.parse(payload).aniimo?.startsWith('roster')) {
                    console.warn('Exact planner failed on a roster:', error);
                    result = JSON.stringify({ success: false, error: `계산을 완료하지 못했습니다. 선택한 생산 방식을 유지하기 위해 대체 계산을 중단했습니다: ${fallbackReason}.` });
                } else {
                    step('backup', 'start');
                    console.warn('Exact planner failed; using the backup planner instead:', error);
                }
            }
            if (!result) {
                // Forwarded straight from the wasm solver's own real trial-solve count (see
                // `find_plan`'s doc comment in wasm.rs); a `type: 'progress'` message, distinct
                // from the final `{ ok, result }` response below, so `app.js`'s `callWorker` can
                // relay it to a live progress bar without resolving the request early.
                const onProgress = (count) => self.postMessage({ id, type: 'progress', count });
                const plan = JSON.parse(pkg.find_plan(payload, onProgress));
                plan.fallback_reason = fallbackReason;
                result = JSON.stringify(plan);
            }
            self.postMessage({ id, ok: true, result });
            return;
        }
        const handler = HANDLER_NAMES.includes(type) ? pkg[type] : null;
        if (!handler) {
            throw new Error(`Unknown worker request type: ${type}`);
        }
        const result = payload === undefined ? handler() : handler(payload);
        self.postMessage({ id, ok: true, result });
    } catch (error) {
        if (type === 'set_catalog') catalogError = error;
        self.postMessage({ id, ok: false, error: error && error.message ? error.message : String(error) });
    }
};
