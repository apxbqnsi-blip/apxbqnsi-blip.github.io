// Fixed public RV 1–22 catalog. No editor, imports or local catalog overrides.
export const MODULES = ['ecological_module', 'kitchen_module', 'resource_detector', 'crafting_module'];
async function loadCatalog() {
    if (typeof window === 'undefined' && typeof self === 'undefined') {
        const fs = await import('node:fs/promises');
        return JSON.parse(await fs.readFile(new URL('./data/game-data.json', import.meta.url), 'utf8'));
    }
    const response = await fetch(new URL('./data/game-data.json', import.meta.url), {cache:'no-cache', credentials:'omit'});
    if (!response.ok) throw new Error('Could not load the RV 22 data. Please reload this page.');
    return response.json();
}
function freeze(value) {
    if (value && typeof value === 'object') { Object.values(value).forEach(freeze); Object.freeze(value); }
    return value;
}
const catalog = await loadCatalog();
if (catalog.schema_version !== 1 || !catalog.rv_levels.length || catalog.rv_levels.some(r => r.level < 1 || r.level > 22)) {
    throw new Error('Invalid RV 1–22 data. Please reload this page.');
}
export const defaultCatalog = freeze(catalog);
export const activeCatalog = defaultCatalog;
export const catalogLoadError = '';
export function setupAt(data, level) {
    const row = data.rv_levels.find(r => r.level === Number(level));
    if (!row) throw new Error('This web version supports RV levels 1–22.');
    return {facilities:Object.fromEntries(data.facilities.map(f => [f.name,[{...row.facilities[f.name]}]])), modules:{...row.modules}};
}
