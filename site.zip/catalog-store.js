// Published catalog only. RV limits come from data, never local editor saves.
import { validateCatalog } from './catalog-validation.js';
export { MODULES, validateCatalog } from './catalog-validation.js';
async function loadCatalog() {
    if (typeof window === 'undefined' && typeof self === 'undefined') {
        const fs = await import('node:fs/promises');
        return JSON.parse(await fs.readFile(new URL('./data/game-data.json', import.meta.url), 'utf8'));
    }
    const response = await fetch(new URL('./data/game-data.json', import.meta.url), {cache:'no-cache', credentials:'omit'});
    if (!response.ok) throw new Error('Could not load the published game data. Please reload this page.');
    return response.json();
}
function freeze(value) {
    if (value && typeof value === 'object') { Object.values(value).forEach(freeze); Object.freeze(value); }
    return value;
}
const catalog = validateCatalog(await loadCatalog());
export const defaultCatalog = freeze(catalog);
export const activeCatalog = defaultCatalog;
export const catalogLoadError = '';
export function setupAt(data, level) {
    const row = data.rv_levels.find(r => r.level === Number(level));
    if (!row) throw new Error(`No published data for RV ${level}.`);
    return {facilities:Object.fromEntries(data.facilities.map(f => [f.name,[{...row.facilities[f.name]}]])), modules:{...row.modules}};
}
