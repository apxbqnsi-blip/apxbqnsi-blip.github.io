window.toggleTheme = function() {
            const body = document.body;
            const button = document.getElementById('themeToggle');
            body.classList.toggle('light');
            if (body.classList.contains('light')) {
                button.textContent = 'dark';
            } else {
                button.textContent = 'light';
            }
        }
        
        window.showHelp = function() {
            document.getElementById('helpModal').classList.add('show');
        }
        
        window.closeHelp = function() {
            document.getElementById('helpModal').classList.remove('show');
        }
        
        window.closeHelpOnBackdrop = function(event) {
            if (event.target.id === 'helpModal') {
                closeHelp();
            }
        }
        
        window.showMath = function() {
            document.getElementById('mathModal').classList.add('show');
            // Trigger MathJax to render
            if (window.MathJax?.typesetPromise) {
                MathJax.typesetPromise();
            }
        }
        
        window.closeMath = function() {
            document.getElementById('mathModal').classList.remove('show');
        }
        
        window.closeMathOnBackdrop = function(event) {
            if (event.target.id === 'mathModal') {
                closeMath();
            }
        }
        
        // Close modal on Escape key
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                closeHelp();
                closeMath();
                closeFacilities();
            }
        });
    
document.querySelector('[data-ui-action="click-0"]').addEventListener('click', event => { showFacilities(); });
document.querySelector('[data-ui-action="click-1"]').addEventListener('click', event => { showMath(); });
document.querySelector('[data-ui-action="click-2"]').addEventListener('click', event => { showHelp(); });
document.querySelector('[data-ui-action="click-3"]').addEventListener('click', event => { toggleTheme(); });
document.querySelector('[data-ui-action="click-4"]').addEventListener('click', event => { closeFacilitiesOnBackdrop(event); });
document.querySelector('[data-ui-action="click-5"]').addEventListener('click', event => { closeFacilities(); });
document.querySelector('[data-ui-action="click-6"]').addEventListener('click', event => { closeMathOnBackdrop(event); });
document.querySelector('[data-ui-action="click-7"]').addEventListener('click', event => { closeMath(); });
document.querySelector('[data-ui-action="click-8"]').addEventListener('click', event => { closeHelpOnBackdrop(event); });
document.querySelector('[data-ui-action="click-9"]').addEventListener('click', event => { closeHelp(); });
