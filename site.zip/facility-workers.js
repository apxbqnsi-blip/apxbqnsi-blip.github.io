const EXCLUDED = new Set(['Farmland', 'Woodland', 'Heat Furnace', 'Cooling Unit', 'Sunlamp']);
export const canAssignFacilityWorker = name => !EXCLUDED.has(name);

export function facilitySlots(tiers = []) {
    const slots = [];
    for (const tier of tiers) {
        const count = Math.max(0, Math.min(10000 - slots.length, Number(tier.count) || 0));
        for (let i = 0; i < count; i++) slots.push({ unit: slots.length + 1, level: Number(tier.level) || 1 });
    }
    return slots;
}

export function normalizeFacilityWorkers(raw, facilities) {
    const result = {};
    for (const [facility, tiers] of Object.entries(facilities || {})) {
        if (!canAssignFacilityWorker(facility)) continue;
        const count = facilitySlots(tiers).length;
        const entries = new Map();
        for (const row of Array.isArray(raw?.[facility]) ? raw[facility] : []) {
            if (!Number.isInteger(row?.unit) || row.unit < 1 || row.unit > count) continue;
            const value = { unit: row.unit };
            if (Number.isInteger(row.suitability) && row.suitability >= 1 && row.suitability <= 4) value.suitability = row.suitability;
            if (typeof row.personality_bonus === 'boolean') value.personality_bonus = row.personality_bonus;
            if (Object.keys(value).length > 1) entries.set(value.unit, value);
        }
        if (entries.size) result[facility] = [...entries.values()].sort((a, b) => a.unit - b.unit);
    }
    return result;
}

export function workerEditorRows(facility, tiers, values, { escapeText, personality, roster = false }) {
    const slots = facilitySlots(tiers);
    const configured = new Map((values[facility] || []).map(r => [r.unit, r]));
    const disabled = roster ? ' disabled' : '';
    const option = (value, label, chosen) => `<option value="${value}"${String(chosen ?? '') === value ? ' selected' : ''}>${escapeText(label)}</option>`;
    return `<p class="hint small">미입력 항목은 현재 애니모 설정을 따릅니다. 레시피의 필요 능력보다 낮으면 이 시설에서 생산하지 않습니다.</p>
        ${roster ? '<p class="hint small">내 애니모 모드에서는 보유 명단으로 계산합니다. 아래 지정은 최적 애니모·최소 능력에서 적용됩니다.</p>' : ''}
        ${slots.length ? slots.map(({ unit, level }) => {
            const row = configured.get(unit) || {};
            return `<div class="facility-worker-row" data-worker-unit="${unit}">
                <span class="facility-worker-unit">${unit}호 <small>시설 Lv.${level}</small></span>
                <label>애니모 능력<select data-worker-field="suitability" aria-label="${escapeText(facility)} ${unit}호 애니모 레벨"${disabled}>
                    ${option('', '기본 설정', row.suitability)}${[1,2,3,4].map(l => option(String(l), `${l}레벨`, row.suitability)).join('')}
                </select></label>
                <label>성격 보너스<select data-worker-field="personality_bonus" aria-label="${escapeText(facility)} ${unit}호 성격 보너스"${disabled}${!personality ? ' disabled' : ''}>
                    ${option('', personality ? '기본 설정' : '보너스 없는 시설', row.personality_bonus)}${personality ? option('true', `있음 · ${personality}`, row.personality_bonus) + option('false', '없음', row.personality_bonus) : ''}
                </select></label>
            </div>`;
        }).join('') : '<p class="hint small">보유 시설 수를 입력하면 지정할 수 있습니다.</p>'}
        ${configured.size ? '<button type="button" class="skip-add-btn worker-reset">이 시설 기본값 복원</button>' : ''}`;
}

// The solver keeps worker pools separate; attach their physical numbers to the
// single-production rows without letting any two recipes claim the same unit.
export function assignSingleWorkerUnits(plan) {
    const available = new Map((plan.worker_pools || []).map(p => [p.id, [...p.units]]));
    return (plan.coin_items || []).flatMap(row => {
        if (row.worker_pool == null || row.status !== 'producing') return row;
        const slots = available.get(row.worker_pool);
        if (!slots || slots.length < row.facility_count) throw new Error('시설별 애니모 배정 수가 보유 수를 초과합니다.');
        return slots.splice(0, row.facility_count).map(n => ({ ...row, facility_count: 1,
            busy_units: row.busy_units == null ? null : row.busy_units / row.facility_count,
            unit_ids: [`${row.facility}#${n}`] }));
    });
}
