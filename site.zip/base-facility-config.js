// Static game rules. Editable facilities, recipes and RV limits live in data/game-data.json.

// Aniipod tiers in Aniipod Maker level order: each level adds a better one for catching Aniimo.
// The "Most Aniipods" strategy makes only the best tier the player's Maker can reach.
export const ANIIPOD_TIERS = ['aniipod', 'aniipod_pro', 'aniipod_mega'];

// Recipes unlocked with a rare currency (a few come from RV level-ups or from collecting one of
// every product). Plans leave them out until the player says they have them.
export const SPECIAL_RECIPES = [
    { name: 'rose_shortbread', facility: 'Claw Game Cooker' },
    { name: 'potato_kvass', facility: 'Bouncy Brew Keg' },
    { name: 'ginseng_porridge', facility: 'Simmering Pot' },
    { name: 'strawberry_candy', facility: 'Blazing Stove' },
    { name: 'flowers_in_a_bottle', facility: 'Crafting Table' },
    { name: 'lotion', facility: 'Phonolfactory Table' },
];

// The Harvest Moon Festival, from RV 10: season crops' seeds cost Moonray Wheat, which season
// orders pay out, and every season item sold counts points on top of its coins. Wheat is taken as
// unlimited; plans show how much their seeds use. The recipes and seed costs are in
// data/harvest_moon_festival.csv.
export const SEASON = {
    name: 'Harvest Moon Festival',
    currency: 'Moonray Wheat',
    points: 'Harvest Moon Points',
    minHomeLevel: 10,
    // Recipes unlocked with Recipe Notes; plans only use the ones the player ticks. The season's
    // other recipes come unlocked.
    recipeNotes: [
        { name: 'harvest_platter' },
        { name: 'umbral_pickle' },
        { name: 'umbral_hot_pot' },
        { name: 'umbral_sweet_and_spicy_sauce' },
    ],
};


// The Woodworking Bench and Chimney Kiln chains, lowest tier first: what a player might have in
// stock toward a level-up.
export const LEVEL_UP_CHAINS = [
    ['wood_block', 'rough_lumber', 'standard_planks', 'laminated_beams', 'densified_timber_component'],
    ['mineral_sand', 'coarse_sifted_ore', 'sintered_ore_brick', 'refined_ore', 'microcrystalline_ore_plate'],
];


// The homeland: a 4x4 grid of plots, each 20 tiles wide and 15 tall, plot n opening at RV n (and
// all of them from RV 16). Rows from the top, by plot number; the first opens bottom middle.
export const HOMELAND_PLOT_SIZE = { w: 20, h: 15 };
export const HOMELAND_PLOTS = [
    [13, 14, 15, 16],
    [12, 7, 8, 9],
    [11, 4, 3, 6],
    [10, 2, 1, 5],
];

// An Aniimo carries four personalities at once, one from each of these opposed pairs, which the
// game shows as four letters over its portrait: INFP, ISFJ, ESTJ and so on. So one Aniimo can
// hold the bonus for up to four facilities, and can never hold it for two that want opposite
// personalities. Seven of the names are their own letter; S is Practical, confirmed in game.
export const PERSONALITY_PAIRS = [
    { letters: ['I', 'E'], names: ['Instinctive', 'Energetic'] },
    { letters: ['N', 'S'], names: ['Nimble', 'Practical'] },
    { letters: ['F', 'T'], names: ['Faithful', 'Tenacious'] },
    { letters: ['P', 'J'], names: ['Playful', 'Judicious'] },
];

/// The letter the game shows for a personality, and the personality it rules out.
export function personalityLetter(name) {
    const pair = PERSONALITY_PAIRS.find(p => p.names.includes(name));
    return pair ? pair.letters[pair.names.indexOf(name)] : null;
}

export function opposedPersonality(name) {
    const pair = PERSONALITY_PAIRS.find(p => p.names.includes(name));
    return pair ? pair.names[1 - pair.names.indexOf(name)] : null;
}

// Display order for facility categories. Auxiliary facilities (Storage Unit, power/climate
// buildings) are deliberately excluded here: they don't produce items.
export const FACILITY_CATEGORIES = ['Materials', 'Environment', 'Aniimo Materials', 'Materials Processing'];

