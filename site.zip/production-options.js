// Event crops keep their plots while their real harvests, costs and jobs enter every plan.
import { defaultCatalog, activeCatalog } from './catalog-store.js';
export const eventPreset = index => structuredClone(defaultCatalog.event_crop_presets[index]);
export const eventSeedCurrency = activeCatalog.season_config?.currency || defaultCatalog.season_config.currency;
export const eventId = index => `__event_plot_${index + 1}`;
export const isEvent = name => /^__event_plot_[12]$/.test(name || '');
export const eventRecipeId = (crop, index) => crop.recipe || eventId(index);
export const findEventCrop = (name, crops = []) => crops.find((crop, i) => crop.count > 0 && eventRecipeId(crop, i) === name);
export const eventCropRecipes = () => activeCatalog.recipes.filter(r => r.facility === 'Farmland' && r.season);
export const EVENT_ABILITIES = ['Fire', 'Grass', 'Water', 'Earth', 'Lightning', 'Ice', 'Wind', 'Dark', 'Light', 'Hauling', 'Artisanship', 'Leisure', 'Perfumery'];
export const defaultEventJobs = (index = 0) => eventPreset(index).jobs;
export const eventCycle = crop => (crop.growth_seconds ?? 2400) * (crop.watering === false ? 1 : .75);
export function eventJobs(crop) {
    return [...(crop.jobs || []), ...(crop.watering === false ? [] : [0, 1].map(() => ({ step: 'Watering', ability: 'Water', min_level: crop.watering_level ?? 1, seconds: crop.watering_seconds ?? 6 })))];
}
export function eventRecipes(crops = []) {
    return crops.map((crop, i) => ({ name: eventRecipeId(crop, i), label: crop.name, facility: 'Farmland',
        facilityLevel: activeCatalog.recipes.find(r => r.name === crop.recipe)?.facility_level || 1,
        min_rv_level: activeCatalog.recipes.find(r => r.name === crop.recipe)?.min_rv_level,
        module_requirement: activeCatalog.recipes.find(r => r.name === crop.recipe)?.module_requirement,
        environment: crop.environment || null, ingredients: [], amounts: [], yieldAmount: crop.yield_amount,
        production_time: eventCycle(crop), sell_value: crop.sell_value, sell_currency: 'coins',
        jobs: eventJobs(crop).map(j => [j.step, j.ability, j.min_level]), cost: crop.seed_cost,
        seasonSeedCost: crop.season_seed_cost || 0, season: !!(crop.season_seed_cost || crop.season_points), turns: false, event: true })).filter((_, i) => crops[i].count > 0);
}
export function withEventRecipes(recipes, crops = []) {
    return [...recipes.filter(r => !r.event && !isEvent(r.name) && !(r.facility === 'Farmland' && r.season)), ...eventRecipes(crops)];
}
export function validateEvents(crops, total, { economics = true } = {}) {
    if (crops.length > 2) throw new Error('이벤트 작물은 2종까지 입력할 수 있습니다.');
    const bindings = new Set();
    for (const crop of crops) {
        if (!Number.isSafeInteger(crop.count) || crop.count < 0 || crop.count > 4294967295) throw new Error('이벤트 밭 수는 0 이상의 정수로 입력하세요.');
        if (crop.count && !crop.name.trim()) throw new Error('이벤트 밭을 예약할 작물의 이름을 입력하세요.');
        if (crop.environment && !['Warm', 'Scorching', 'Cool', 'Freeze', 'Adequate'].includes(crop.environment)) throw new Error('이벤트 작물의 환경 조건을 목록에서 선택하세요.');
        if (crop.count > 0 && crop.recipe) {
            if (!eventCropRecipes().some(r => r.name === crop.recipe)) throw new Error(`${crop.name}: 연결할 시즌 밭 레시피를 확인하세요.`);
            if (bindings.has(crop.recipe)) throw new Error('같은 이벤트 작물 레시피를 두 예약 칸에 중복 연결할 수 없습니다.');
            bindings.add(crop.recipe);
        }
    }
    const reserved = crops.reduce((n, c) => n + c.count, 0);
    if (reserved > total) throw new Error(`이벤트 밭 ${reserved}칸이 전체 밭 ${total}칸을 초과합니다.`);
    if (economics) for (const crop of crops.filter(c => c.count > 0)) {
        if (!Number.isSafeInteger(crop.yield_amount) || crop.yield_amount < 1 || crop.yield_amount > 4294967295) throw new Error(`${crop.name}: 1칸당 수확량을 1 이상의 정수로 입력하세요.`);
        for (const [field, label] of [['sell_value', '개당 판매가'], ['seed_cost', '1회 씨앗 비용']]) {
            if (crop[field] == null || !Number.isFinite(crop[field]) || crop[field] < 0) throw new Error(`${crop.name}: ${label}을 0 이상으로 입력하세요.`);
        }
        const growth = crop.growth_seconds ?? 2400;
        for (const key of ['season_seed_cost', 'season_points']) if (crop[key] != null && (!Number.isFinite(crop[key]) || crop[key] < 0)) throw new Error(`${crop.name}: 시즌 비용과 포인트는 0 이상으로 입력하세요.`);
        if (!Number.isFinite(growth) || growth <= 0 || growth > 31536000) throw new Error(`${crop.name}: 성장 시간을 올바르게 입력하세요.`);
        if (!Array.isArray(crop.jobs) || crop.jobs.length > 12) throw new Error(`${crop.name}: 작업 애니모 목록을 확인하세요 (최대 12개).`);
        for (const job of crop.jobs) if (!job.step?.trim() || job.step.length > 50 || job.step === 'Watering' || !EVENT_ABILITIES.includes(job.ability)
            || !Number.isInteger(job.min_level) || job.min_level < 1 || job.min_level > 4 || !Number.isFinite(job.seconds) || job.seconds <= 0 || job.seconds > 86400) {
            throw new Error(`${crop.name}: 작업명·능력·필요 레벨(1~4)·작업시간을 확인하세요. 물주기는 별도 항목입니다.`);
        }
        const waterLevel = crop.watering_level === undefined ? 1 : crop.watering_level;
        const waterSeconds = crop.watering_seconds === undefined ? 6 : crop.watering_seconds;
        if (crop.watering !== false && (!Number.isInteger(waterLevel) || waterLevel < 1 || waterLevel > 4
            || !Number.isFinite(waterSeconds) || waterSeconds <= 0 || waterSeconds > 86400)) throw new Error(`${crop.name}: 물주기의 필요 레벨과 1회 작업시간을 확인하세요.`);
    }
    return { total, reserved, ordinary: total - reserved };
}
export function productOf(name, recipes) {
    return name.startsWith('quick_') && recipes.some(r => r.name === name.slice(6)) ? name.slice(6) : name;
}
export function productionRates(plan, recipes) {
    const byName = new Map(recipes.map(r => [r.name, r]));
    const gross = new Map(), net = new Map();
    for (const step of plan?.coin_items || []) {
        if (step.status !== 'producing' || !(step.cycle_time > 0)) continue;
        const r = byName.get(step.item_name);
        if (!r || !(r.yieldAmount > 0)) continue;
        const batches = (step.busy_units ?? step.facility_count) / step.cycle_time;
        const produced = batches * r.yieldAmount;
        gross.set(r.name, (gross.get(r.name) || 0) + produced);
        const product = productOf(r.name, recipes);
        net.set(product, (net.get(product) || 0) + produced);
        if (r.byproduct) net.set(r.byproduct, (net.get(r.byproduct) || 0) + batches * r.byproductAmount);
        r.ingredients.forEach((ingredient, i) => net.set(ingredient, (net.get(ingredient) || 0) - batches * r.amounts[i]));
    }
    return { gross, net };
}
export function compareProduction(baseline, candidate, recipes) {
    const a = productionRates(baseline, recipes), b = productionRates(candidate, recipes);
    const rows = [...new Set([...a.gross.keys(), ...b.gross.keys()])].map(name => ({ name,
        before: (a.gross.get(name) || 0) * 3600, after: (b.gross.get(name) || 0) * 3600,
        delta: ((b.gross.get(name) || 0) - (a.gross.get(name) || 0)) * 3600 }));
    return { before: a, after: b, rows };
}
// Explain missing gates through the ingredient chain. Alternative quick recipes may satisfy a
// material, so a locked ordinary recipe alone must not mark the whole chain impossible.
export function recipeBlockers(target, input, recipes) {
    const cropProducts = new Set(recipes.filter(r => r.facility === 'Farmland' && r.season).map(r => r.name));
    recipes = withEventRecipes(recipes, input.event_crops || []);
    const eligible = r => {
        const errors = [];
        if ((r.min_rv_level || 1) > (input.rv_level ?? 1)) errors.push(`${r.name}: RV ${r.min_rv_level} 이상이 필요합니다.`);
        if (!(input.facilities[r.facility] || []).some(t => t.count > 0 && t.level >= r.facilityLevel)) errors.push(`${r.facility} Lv.${r.facilityLevel} 시설 부족`);
        if (r.module_requirement && (input.modules[r.module_requirement[0]] || 0) < r.module_requirement[1]) errors.push(`${r.module_requirement[0]} Lv.${r.module_requirement[1]} 필요`);
        if (!r.event && input.exclude?.includes(r.name)) errors.push(`${r.name}: 제외되었거나 특수 레시피 미해금`);
        if (!r.event && r.season && !input.season) errors.push(`${r.name}: 시즌 레시피 사용이 꺼져 있음`);
        if (r.aniimo && input.aniimo?.startsWith('best') && (input.aniimo_levels?.[r.aniimo[0]] ?? 4) < r.aniimo[1]) errors.push(`${r.name}: ${r.aniimo[0]} 능력 Lv.${r.aniimo[1]} 필요`);
        return errors;
    };
    function visit(product, stack = new Set()) {
        if (stack.has(product)) return []; // Capacity/cycles are decided by the solver.
        const sources = recipes.filter(r => productOf(r.name, recipes) === product || r.byproduct === product);
        if (!sources.length) return [cropProducts.has(product)
            ? `${product}: 이벤트 밭 예약에서 이 작물을 연결하고 예약할 밭 칸 수를 1 이상으로 입력하세요.`
            : `${product}: 원재료를 만드는 레시피 데이터 없음`];
        const next = new Set(stack); next.add(product);
        const failures = sources.map(r => [...eligible(r), ...r.ingredients.flatMap(n => visit(n, next))]);
        if (failures.some(errors => !errors.length)) return [];
        return [...new Set(failures.flat())];
    }
    return visit(target);
}
